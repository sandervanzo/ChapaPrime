# -*- coding: utf-8 -*-
from __future__ import annotations

from math import ceil
from datetime import datetime
from typing import List, Dict, Any

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.lib import colors

from services.calc import calc_blank_mm, peso_peca_kg, fmt

try:
    from app.app_meta import APP_NAME, APP_VERSION
except Exception:
    APP_NAME, APP_VERSION = "ChapaPrime", "1.0.0"

try:
    from config.settings import settings as _cfg
    _DENS_DEFAULT = float(_cfg.get("default_density_kg_m3", 8000.0))
except Exception:
    _DENS_DEFAULT = 8000.0


# ======== estilos ========
GRID_STROKE_PT = 0.3
HEAD_STROKE_PT = 0.8
BOX_STROKE_PT  = 0.7
BOX_RADIUS     = 3.5 * mm
FRAME_RADIUS   = 6.0 * mm

ZEBRA_FILL = (0.965, 0.970, 0.985)
GRID_COLOR = (0.80, 0.80, 0.85)
HEAD_BG    = (0.12, 0.13, 0.22)

CELL_FONT = "Helvetica"
CELL_SIZE = 8
HEAD_FONT = "Helvetica-Bold"
HEAD_SIZE = 8

# Altura do cabeçalho da tabela (aumentei para suportar 2 linhas)
HEADER_H = 10 * mm


# ======== cabeçalho topo ========
def _draw_header_band(c: canvas.Canvas, x: float, y_top: float, w: float, header: dict) -> float:
    band_h = 14 * mm
    c.setFillColorRGB(*HEAD_BG)
    c.roundRect(x, y_top - band_h, w, band_h, BOX_RADIUS, stroke=0, fill=1)

    y_meta = y_top - 3.8 * mm
    c.setFillColor(colors.white)
    c.setFont(CELL_FONT, 8)
    c.drawString(x + 2 * mm, y_meta, f"{APP_NAME} | OP de Dobra | v{APP_VERSION}")
    c.drawRightString(x + w - 2 * mm, y_meta,
                      f"ENTRADA: {header.get('entrada','')}    SAÍDA: {header.get('saida','')}")

    y_title = y_top - 10.2 * mm
    c.setFont("Helvetica-Bold", 12)
    c.drawCentredString(x + w / 2, y_title, f"ORDEM DE DOBRA {header.get('op','S/N')}")
    return y_top - band_h - 6 * mm


def _draw_client_box(c: canvas.Canvas, x: float, y_top: float, w: float, header: dict) -> float:
    box_h = 20 * mm
    box_y = y_top - box_h
    c.setFillColor(colors.white)
    c.setStrokeColor(colors.black)
    c.setLineWidth(BOX_STROKE_PT)
    c.roundRect(x, box_y, w, box_h, BOX_RADIUS, stroke=1, fill=0)

    c.setFont(CELL_FONT, 9); c.setFillColor(colors.black)
    c.drawString(x + 6 * mm,  box_y + box_h - 8 * mm, "CLIENTE:")
    c.drawString(x + w/2,     box_y + box_h - 8 * mm, "COLETA:")
    c.drawString(x + 6 * mm,  box_y + 6 * mm,         "OBRA:")

    c.setFont("Helvetica-Bold", 10)
    c.drawString(x + 26 * mm,         box_y + box_h - 8 * mm, header.get('cliente', ''))
    c.drawString(x + w/2 + 20 * mm,   box_y + box_h - 8 * mm, header.get('coleta', ''))
    c.drawString(x + 26 * mm,         box_y + 6 * mm,         header.get('obra', ''))
    return box_y - 10 * mm   # respiro extra antes da tabela


# ======== tabela ========
# Redistribuição: mais espaço para ESP/BLANK/COMPR/PESOS, sem estourar a largura total.
_BASE_COLW_MM = [12, 14, 16, 27, 10, 10, 10, 19, 23, 20, 22, 23, 6, 6, 6]
_COLS = [
    "ITEM","QUANT","PERFIL","REF/DESC","ALMA","MESA","ENRIJ",
    "ESP","BLANK","COMPR","PESO PC","PESO TOT","D","E","R"
]
# unidades (em 2ª linha no cabeçalho)
_COL_UNITS = {7: "mm", 8: "mm", 9: "mm", 10: "kg", 11: "kg"}

_ALIGNS = ["C","C","C","L","R","R","R","R","R","R","R","R","C","C","C"]

# índices das colunas D/E/R
IDX_D, IDX_E, IDX_R = 12, 13, 14

def _scaled_col_widths(w_available_pt: float):
    total_base_pt = sum(_BASE_COLW_MM) * mm
    s = w_available_pt / total_base_pt
    return [cw * mm * s for cw in _BASE_COLW_MM]  # em pt, somando = w_available_pt

def _draw_table_header(c: canvas.Canvas, x: float, y: float, w_available_pt: float, colw):
    # fundo
    c.setFillColorRGB(*HEAD_BG)
    c.rect(x, y - HEADER_H, w_available_pt, HEADER_H, stroke=0, fill=1)

    # títulos (2 linhas para quem tem unidade)
    xs = [x]
    for wcol in colw[:-1]:
        xs.append(xs[-1] + wcol)

    c.setFillColor(colors.white)
    for i, label in enumerate(_COLS):
        cx = xs[i] + colw[i] / 2
        if i in _COL_UNITS:
            c.setFont(HEAD_FONT, HEAD_SIZE)
            c.drawCentredString(cx, y - 3.0 * mm, label)
            c.setFont(CELL_FONT, 7)
            c.drawCentredString(cx, y - 6.6 * mm, f"({_COL_UNITS[i]})")
        else:
            c.setFont(HEAD_FONT, HEAD_SIZE)
            c.drawCentredString(cx, y - 3.8 * mm, label)

    # divisórias verticais internas do cabeçalho (brancas finas)
    c.setStrokeColor(colors.white); c.setLineWidth(0.6)
    for x_div in xs[1:]:   # sem a borda esquerda
        c.line(x_div, y, x_div, y - HEADER_H)

    # topo/base do header (pretas)
    c.setStrokeColor(colors.black); c.setLineWidth(HEAD_STROKE_PT)
    c.line(x, y - HEADER_H, x + w_available_pt, y - HEADER_H)
    c.line(x, y,           x + w_available_pt, y)
    c.setLineWidth(GRID_STROKE_PT)


def _draw_cell(c: canvas.Canvas, x: float, w: float, yb: float, text: str, align: str):
    c.setFont(CELL_FONT, CELL_SIZE)
    pad = 3  # padding um pouco maior
    if align == "L":
        t = str(text)
        max_w = max(0, w - 2 * pad)
        while c.stringWidth(t, CELL_FONT, CELL_SIZE) > max_w and len(t) > 1:
            t = (t[:-1] + "...") if not t.endswith("...") else (t[:-4] + "...")
        c.drawString(x + pad, yb, t)
    elif align == "R":
        c.drawRightString(x + w - pad, yb, str(text))
    else:
        c.drawCentredString(x + w/2, yb, str(text))


def _fmt_int(v) -> str:
    try:
        return str(int(round(float(v))))
    except Exception:
        return str(v)


# ======== footer ========
def _draw_footer(c: canvas.Canvas, W: float, margin: float, page: int, pages: int):
    c.setFont(CELL_FONT, 8); c.setFillColor(colors.black)
    y = margin + 2 * mm   # rodapé dentro da moldura
    c.drawString(margin, y, f"Gerado em {datetime.now().strftime('%d/%m/%Y %H:%M')}")
    c.drawRightString(W - margin, y, f"Página {page}/{pages}")


# ======== principal ========
def export_op_dobra_pdf(filename, header: dict, items: List[Dict[str, Any]], dens: float | None = None):
    densidade = float(dens) if dens is not None else _DENS_DEFAULT

    c = canvas.Canvas(filename, pagesize=A4)
    W, H = A4
    margin = 16 * mm
    x = margin
    y = H - margin
    w = W - 2 * margin   # área útil horizontal

    # Moldura
    c.setStrokeColor(colors.black); c.setLineWidth(1)
    c.roundRect(margin - 6, margin - 6, W - 2*(margin - 6), H - 2*(margin - 6), FRAME_RADIUS, stroke=1, fill=0)

    # Topo + cliente
    y = _draw_header_band(c, x, y, w, header)
    y = _draw_client_box(c, x, y, w, header)

    # Tabela (larguras ESCALADAS para caber exatamente em w)
    colw = _scaled_col_widths(w)
    w_total = sum(colw)              # == w
    line_h = 7.5 * mm
    reserve_bottom = 42 * mm

    first_header_h = HEADER_H
    available_first = (y - first_header_h) - (margin + reserve_bottom)
    lines_first = max(1, int(available_first // line_h))

    available_next = (H - margin - 10 * mm - first_header_h) - (margin + reserve_bottom)
    lines_next = max(1, int(available_next // line_h)) if available_next > 0 else 25

    total_items = len(items)
    if total_items <= lines_first:
        pages = 1; breaks = [total_items]
    else:
        remaining = total_items - lines_first
        extra_pages = ceil(remaining / lines_next)
        pages = 1 + extra_pages
        breaks = [lines_first]
        for _ in range(extra_pages):
            take = min(lines_next, remaining)
            breaks.append(breaks[-1] + take)
            remaining -= take

    def _print_table_header_here(_y):
        _draw_table_header(c, x, _y, w_total, colw)
        return _y - HEADER_H

    y = _print_table_header_here(y)

    total_kg = 0.0
    total_qtd = 0
    page_idx = 1
    printed = 0

    xs = [x]
    for wcol in colw[:-1]:
        xs.append(xs[-1] + wcol)

    # para caixas D/E/R
    box_sz = 3 * mm
    box_pad_y = (line_h - box_sz) / 2

    for idx, it in enumerate(items, start=1):
        printed += 1

        alma = it.get("alma", 0); mesa = it.get("mesa", 0); enrij = it.get("enrij", 0)
        esp = it.get("esp", 0); comp = it.get("compr", 0); qtd = int(it.get("quant", 1))
        ndb = int(header.get("dobras", it.get("dobras", 2)))

        try:
            blank = int(round(float(it.get("blank", 0) or 0)))
        except Exception:
            blank = 0
        if blank <= 0:
            blank = calc_blank_mm(alma, mesa, enrij, esp, ndb)

        if bool(it.get("peso_manual", False)):
            peso = float(it.get("peso_pc", 0.0))
        else:
            peso = peso_peca_kg(esp, blank, comp, densidade)

        ptot = peso * qtd
        total_kg += ptot
        total_qtd += qtd

        if printed > breaks[page_idx - 1]:
            _draw_footer(c, W, margin, page=page_idx, pages=pages)
            c.showPage()
            page_idx += 1
            c.setFont("Helvetica-Bold", 10)
            c.drawString(margin, H - margin, f"ORDEM DE DOBRA {header.get('op','S/N')} (cont.)")
            c.setFont(CELL_FONT, 8)
            c.drawRightString(W - margin, H - margin, f"{APP_NAME} | v{APP_VERSION}")
            y = H - margin - 10 * mm
            y = _print_table_header_here(y)

        # zebra
        if idx % 2 == 0:
            c.setFillColorRGB(*ZEBRA_FILL)
            c.rect(x, y - line_h, w_total, line_h, stroke=0, fill=1)
            c.setFillColor(colors.black)

        vals = [
            idx, qtd, it.get("perfil",""), it.get("ref","") or it.get("refdesc",""),
            _fmt_int(alma), _fmt_int(mesa), _fmt_int(enrij),
            f"{float(esp):.2f}", _fmt_int(blank), _fmt_int(comp),
            fmt(peso,2), fmt(ptot,2), "", "", ""  # D/E/R com caixas
        ]

        yb = y - 5 * mm
        for i, v in enumerate(vals):
            if i in (IDX_D, IDX_E, IDX_R):
                continue
            _draw_cell(c, xs[i], colw[i], yb, v, _ALIGNS[i])

        # ---- caixinhas D / E / R ----
        c.setStrokeColor(colors.black); c.setLineWidth(0.8)
        flags = [bool(it.get("d")), bool(it.get("e")), bool(it.get("r"))]
        for j, col_idx in enumerate((IDX_D, IDX_E, IDX_R)):
            cx = xs[col_idx] + (colw[col_idx] - box_sz) / 2
            cy = y - line_h + box_pad_y
            c.rect(cx, cy, box_sz, box_sz, stroke=1, fill=0)
            if flags[j]:
                c.line(cx + 1, cy + 1, cx + box_sz - 1, cy + box_sz - 1)
                c.line(cx + box_sz - 1, cy + 1, cx + 1, cy + box_sz - 1)

        # grade horizontal + divisórias verticais internas
        c.setStrokeColorRGB(*GRID_COLOR); c.setLineWidth(GRID_STROKE_PT)
        c.line(x, y - line_h, x + w_total, y - line_h)  # horizontal
        for x_div in xs[1:]:                            # verticais internas
            c.line(x_div, y, x_div, y - line_h)

        y -= line_h

    # respiro antes do total
    y -= 3 * mm

    # TOTAL/QTD
    c.setFillColor(colors.white)
    c.setStrokeColor(colors.black); c.setLineWidth(HEAD_STROKE_PT)
    left_w  = 50 * mm * (w_total/(sum(_BASE_COLW_MM)*mm))
    right_w = w_total - left_w
    c.line(x, y,             x + left_w, y)
    c.line(x, y - 8 * mm,    x + left_w, y - 8*mm)
    c.setFont("Helvetica-Bold", 9)
    c.drawString(x + 3 * mm, y - 5 * mm, "TOTAL (kg) / Qtd.")
    c.drawRightString(x + left_w - 4, y - 5 * mm, str(total_qtd))

    c.setFillColorRGB(0.92,0.92,0.92)
    c.rect(x + left_w, y - 8*mm, right_w, 8*mm, stroke=1, fill=1)
    c.setFillColor(colors.black); c.setFont("Helvetica-Bold", 9)
    c.drawString(x + left_w + 2*mm, y - 5*mm, "T. PEÇAS (kg):")
    c.drawRightString(x + w_total - 4, y - 5*mm, fmt(total_kg,2))

    # ===== bloco OPERAÇÃO ancorado no rodapé =====
    row_h = 10 * mm
    op_block_h = 7 * row_h
    target_gap_bottom = 10 * mm
    desired_top_y = margin + target_gap_bottom + op_block_h
    if page_idx == 1 and y > desired_top_y:
        y = desired_top_y

    c.setFillColorRGB(1,1,0)
    c.rect(x, y - row_h, left_w, row_h, stroke=0, fill=1)
    c.rect(x + left_w, y - row_h, right_w, row_h, stroke=0, fill=1)

    c.setStrokeColor(colors.black); c.setLineWidth(1)
    c.line(x, y, x + w_total, y)
    c.line(x, y - row_h, x + w_total, y - row_h)

    c.setFillColor(colors.black); c.setFont("Helvetica-Bold", 9)
    c.drawCentredString(x + left_w/2, y - 6*mm, "OPERAÇÃO\n(DOBRA)")

    cw = right_w / 4.0
    labels = ["DATA","INÍCIO","FIM","TOTAL HORA"]
    for i, l in enumerate(labels):
        x_div = x + left_w + cw * i
        if i > 0:
            c.line(x_div, y, x_div, y - row_h)
        c.drawCentredString(x + left_w + cw*(i + 0.5), y - 6*mm, l)

    c.setFillColor(colors.white)
    c.setLineWidth(HEAD_STROKE_PT)
    for i in range(6):
        yy = y - row_h * (i + 1)
        c.rect(x, yy - row_h, w_total, row_h, stroke=0, fill=1)
        c.setStrokeColor(colors.black)
        c.line(x, yy - row_h, x + w_total, yy - row_h)

    _draw_footer(c, W, margin, page=page_idx, pages=1)
    c.showPage()
    c.save()
