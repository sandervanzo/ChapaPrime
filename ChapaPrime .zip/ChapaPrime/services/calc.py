from __future__ import annotations

# =========================================================
# Funções originais (preservadas)
# =========================================================

def mm_to_m(x: float) -> float:
    return float(x) / 1000.0

def fmt(v: float, dec: int=2) -> str:
    try:
        return f"{float(v):,.{dec}f}".replace(",", "X").replace(".", ",").replace("X", ".")
    except Exception:
        return str(v)

def parse_float(s, default=0.0):
    try:
        if s is None: return default
        if isinstance(s, (int,float)): return float(s)
        s = str(s).strip().replace(" ", "")
        s = s.replace(".", "").replace(",", ".") if s.count(",")==1 and s.count(".")>1 else s.replace(",", ".")
        return float(s)
    except Exception:
        return default

def calc_blank_mm(alma, mesa, enrij, esp, n_dobras) -> int:
    alma  = parse_float(alma)
    mesa  = parse_float(mesa)
    enrij = parse_float(enrij)
    esp   = parse_float(esp)
    n     = int(parse_float(n_dobras))
    blank = max(0.0, alma + 2*mesa + 2*enrij - 2*esp*n)
    return int(round(blank))

def peso_peca_kg(esp_mm, blank_mm, compr_mm, densidade_kg_m3=8000.0) -> float:
    e = mm_to_m(parse_float(esp_mm))
    b = mm_to_m(parse_float(blank_mm))
    c = mm_to_m(parse_float(compr_mm))
    return e*b*c*densidade_kg_m3


# =========================================================
# ChapaPrime – Acrescímos (compatíveis e sem quebrar nada)
# =========================================================
# - Leitura opcional de configuração (densidade/kerf) se houver config/settings.py
# - Novas funções utilitárias de peso e área efetiva (com kerf)
# - Wrapper opcional para usar a densidade padrão do config na função original

try:
    # se existir, usamos os valores do config
    from config.settings import settings as _cfg
    _DENS_DEFAULT = float(_cfg.get("default_density_kg_m3", 8000.0))
    _KERF_DEFAULT = float(_cfg.get("kerf_mm", 3.0))
except Exception:
    # fallback seguro se o módulo de config ainda não estiver criado
    _cfg = None
    _DENS_DEFAULT = 8000.0
    _KERF_DEFAULT = 3.0


def kg_from_area_thickness(area_mm2: float, thickness_mm: float, density_kg_m3: float | None = None) -> float:
    """
    Converte área (mm²) + espessura (mm) em kg.
    Fórmula: kg = área(m²) × espessura(m) × densidade(kg/m³)
    """
    if density_kg_m3 is None:
        density_kg_m3 = _DENS_DEFAULT
    area_m2 = parse_float(area_mm2) / 1_000_000.0     # mm² -> m²
    thickness_m = parse_float(thickness_mm) / 1000.0  # mm  -> m
    return area_m2 * thickness_m * float(density_kg_m3)


def effective_area_mm2(area_mm2: float, total_cut_length_mm: float, kerf_mm: float | None = None) -> float:
    """
    Retorna a área efetiva descontando a perda de corte (kerf).
    Área_efetiva ≈ área - (comprimento_total_de_cortes × kerf)
    """
    if kerf_mm is None:
        kerf_mm = _KERF_DEFAULT
    area_mm2 = parse_float(area_mm2)
    cut_len_mm = parse_float(total_cut_length_mm)
    lost_mm2 = max(0.0, cut_len_mm * parse_float(kerf_mm))  # mm × mm = mm²
    eff = area_mm2 - lost_mm2
    return eff if eff > 0 else 0.0


def kg_from_effective(area_mm2: float, thickness_mm: float, total_cut_length_mm: float,
                      density_kg_m3: float | None = None, kerf_mm: float | None = None) -> float:
    """
    Peso (kg) usando a área efetiva (com kerf).
    """
    eff_area = effective_area_mm2(area_mm2, total_cut_length_mm, kerf_mm)
    return kg_from_area_thickness(eff_area, thickness_mm, density_kg_m3)


def peso_peca_kg_cfg(esp_mm, blank_mm, compr_mm, densidade_kg_m3: float | None = None) -> float:
    """
    Wrapper compatível da função original 'peso_peca_kg' usando densidade do config,
    quando 'densidade_kg_m3' não for informado.
    """
    if densidade_kg_m3 is None:
        densidade_kg_m3 = _DENS_DEFAULT
    return peso_peca_kg(esp_mm, blank_mm, compr_mm, densidade_kg_m3)
