
import json, os
STORE = os.path.join(os.path.expanduser("~"), ".steelflow_store.json")

def load():
    try:
        if os.path.exists(STORE):
            with open(STORE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}

def save(data: dict):
    try:
        with open(STORE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass
