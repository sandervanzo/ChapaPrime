from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.lib import colors
from services.calc import calc_blank_mm, peso_peca_kg, fmt

# Branding (nome/versão) – usado se o header não passar esses campos
try:
    from app.app_meta import APP_NAME, APP_VERSION
except Exception:
    APP_NAME, APP_VERSION = "ChapaPrime", "1.0.0"


def export_op_dobra_pdf(filename, header: dict, items: list, dens=8000.0):
    """
    Gera o PDF da OP de Dobra.

    Compatibilidade mantida:
    - Assinatura original preservada (apenas o default 'dens' agora é 8000.0).
    - Todo o layout/table original foi mantido.
    - Acrescentei a exibição opcional de 'app_name' e 'app_version' no cabeçalho.
      (Se não existirem no header, usa APP_NAME/APP_VERSION padrão.)
    """
    # Lê app_name/version do header (se vierem do export/op_dobra_pdf.py) ou usa defaults
    app_name = (header or {}).get("app_name", APP_NAME)
    app_version = (header or {}).get("app_version", APP_VERSION)

    c = canvas.Canvas(filename, pagesize=A4)
    W, H = A4
    margin = 16 * mm
    x = margin
    y = H - margin
    w = W - 2 * margin

    # moldura
    c.setStrokeColor(colors.black)
    c.setLineWidth(1)
    c.roundRect(margin - 6, margin - 6, W - 2 * (margin - 6), H - 2 * (margin - 6), 6, stroke=1, fill=0)

    # título (faixa superior)
    c.setFillColorRGB(0.12, 0.13, 0.22)
    c.roundRect(x, y - 16 * mm, w, 12 * mm, 3 * mm, stroke=0, fill=1)

    # linha "app | OP de Dobra | versão" à esquerda (novo)
    c.setFillColor(colors.white)
    c.setFont("Helvetica", 8)
    c.drawString(x + 2 * mm, y - 5 * mm, f"{app_name} | OP de Dobra | v{app_version}")

    # título principal ao centro (original)
    c.setFont("Helvetica-Bold", 12)
    c.drawCentredString(x + w / 2, y - 8 * mm, f"ORDEM DE DOBRA {header.get('op','S/N')}")
    c.setFont("Helvetica", 9)
    c.drawRightString(x + w - 2 * mm, y - 5 * mm, f"ENTRADA: {header.get('entrada','')}    SAÍDA: {header.get('saida','')}")

    # bloco cliente/obra/coleta (original)
    box_y = y - 34 * mm
    c.setFillColor(colors.white)
    c.setStrokeColor(colors.black)
    c.roundRect(x, box_y, w, 18 * mm, 3 * mm, stroke=1, fill=0)
    c.setFont("Helvetica", 9)
    c.setFillColor(colors.black)
    c.drawString(x + 6 * mm, box_y + 12 * mm, "CLIENTE:")
    c.drawString(x + w / 2, box_y + 12 * mm, "COLETA:")
    c.drawString(x + 6 * mm, box_y + 5 * mm, "OBRA:")
    c.setFont("Helvetica-Bold", 10)
    c.drawString(x + 26 * mm, box_y + 12 * mm, header.get('cliente', ''))
    c.drawString(x + w / 2 + 20 * mm, box_y + 12 * mm, header.get('coleta', ''))
    c.drawString(x + 26 * mm, box_y + 5 * mm, header.get('obra', ''))

    # header da tabela (original)
    y = box_y - 6 * mm
    cols = ["ITEM", "QUANT", "PERFIL", "REF/DESC", "ALMA", "MESA", "ENRIJ", "ESP(mm)", "BLANK(mm)", "COMPR(mm)", "PESO PC(kg)", "PESO TOT(kg)", "D", "E", "R"]
    colw = [10 * mm, 12 * mm, 14 * mm, 32 * mm, 12 * mm, 12 * mm, 12 * mm, 16 * mm, 18 * mm, 18 * mm, 18 * mm, 20 * mm, 6 * mm, 6 * mm, 6 * mm]
    c.setFillColorRGB(0.12, 0.13, 0.22)
    c.rect(x, y - 8 * mm, sum(colw), 8 * mm, stroke=0, fill=1)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 8)
    xs = [x]
    for wcol in colw[:-1]:
        xs.append(xs[-1] + wcol)
    for i, h in enumerate(cols):
        c.drawCentredString(xs[i] + colw[i] / 2, y - 3 * mm, h)
    c.setFillColor(colors.black)
    c.rect(x, y - 8 * mm, sum(colw), 8 * mm, stroke=1, fill=0)
    y -= 8 * mm

    # linhas (original)
    total_kg = 0.0
    total_qtd = 0
    line_h = 7 * mm
    c.setFont("Helvetica", 8)
    for idx, it in enumerate(items, start=1):
        alma = it.get("alma", 0)
        mesa = it.get("mesa", 0)
        enrij = it.get("enrij", 0)
        esp = it.get("esp", 0)
        comp = it.get("compr", 0)
        qtd = int(it.get("quant", 1))
        ndb = int(header.get("dobras", it.get("dobras", 2)))
        blank = calc_blank_mm(alma, mesa, enrij, esp, ndb) if not it.get("blank_manual") else int(float(it.get("blank", 0)))
        peso = it.get("peso_pc") or peso_peca_kg(esp, blank, comp, dens)
        ptot = peso * qtd
        total_kg += ptot
        total_qtd += qtd

        # quebra de página (original + pequena indicação do app no topo)
        if y - line_h < margin + 42 * mm:
            c.showPage()
            W, H = A4
            x = margin
            y = H - margin
            # título de continuação (original)
            c.setFont("Helvetica-Bold", 10)
            c.drawString(x, y, f"ORDEM DE DOBRA {header.get('op','S/N')} (cont.)")
            # assinatura do app no topo da página (novo, discreto)
            c.setFont("Helvetica", 8)
            c.drawRightString(x + (W - 2 * margin), y, f"{app_name} | v{app_version}")
            y -= 10 * mm
            # reprint header da tabela (original)
            c.setFillColorRGB(0.12, 0.13, 0.22)
            c.rect(x, y - 8 * mm, sum(colw), 8 * mm, stroke=0, fill=1)
            c.setFillColor(colors.white)
            c.setFont("Helvetica-Bold", 8)
            xs = [x]
            for wcol in colw[:-1]:
                xs.append(xs[-1] + wcol)
            for i, h in enumerate(cols):
                c.drawCentredString(xs[i] + colw[i] / 2, y - 3 * mm, h)
            c.setFillColor(colors.black)
            c.rect(x, y - 8 * mm, sum(colw), 8 * mm, stroke=1, fill=0)
            y -= 8 * mm
            c.setFont("Helvetica", 8)

        # zebra (original)
        if idx % 2 == 0:
            c.setFillColorRGB(0.96, 0.97, 1.0)
            c.rect(x, y - line_h, sum(colw), line_h, stroke=0, fill=1)
            c.setFillColor(colors.black)

        vals = [
            idx, qtd, it.get("perfil", ""), it.get("ref", ""),
            int(alma), int(mesa), int(enrij),
            f"{esp}", f"{blank}", f"{int(float(comp))}",
            fmt(peso, 2), fmt(ptot, 2),
            "X" if it.get("d") else "", "X" if it.get("e") else "", "X" if it.get("r") else ""
        ]
        aligns = ["C", "C", "C", "L", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C"]
        for i, v in enumerate(vals):
            if aligns[i] == "L":
                c.drawString(xs[i] + 2, y - 5 * mm, str(v))
            else:
                c.drawCentredString(xs[i] + colw[i] / 2, y - 5 * mm, str(v))
        c.setStrokeColorRGB(0.8, 0.8, 0.85)
        c.setLineWidth(0.3)
        c.rect(x, y - line_h, sum(colw), line_h, stroke=1, fill=0)
        y -= line_h

    # total (original)
    c.setFillColor(colors.white)
    c.setStrokeColor(colors.black)
    c.rect(x, y - 8 * mm, sum(colw) - 50 * mm, 8 * mm, stroke=1, fill=0)
    c.setFont("Helvetica-Bold", 9)
    c.drawString(x + 3 * mm, y - 5 * mm, "TOTAL")
    c.drawRightString(x + sum(colw) - 50 * mm - 4 * mm, y - 5 * mm, str(total_qtd))

    c.setFillColorRGB(1, 1, 0)
    c.rect(x + sum(colw) - 50 * mm, y - 8 * mm, 50 * mm, 8 * mm, stroke=1, fill=1)
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 9)
    c.drawString(x + sum(colw) - 48 * mm, y - 5 * mm, "T. PEÇAS (kg):")
    c.drawRightString(x + sum(colw) - 2 * mm, y - 5 * mm, fmt(total_kg, 2))

    # regra e quadro operação (original)
    y -= 10 * mm
    c.setFont("Helvetica", 8)
    c.drawString(x, y - 4 * mm, "Regra do BLANK(mm): (ALMA + 2×MESA + 2×ENRIJ) − 2×ESP×DOBRAS")

    y -= 8 * mm
    row_h = 10 * mm
    c.setFillColorRGB(1, 1, 0)
    c.rect(x, y - row_h, 50 * mm, row_h, stroke=1, fill=1)
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 9)
    c.drawCentredString(x + 25 * mm, y - 6 * mm, "OPERAÇÃO\n(DOBRA)")

    c.setFillColorRGB(1, 1, 0)
    c.rect(x + 50 * mm, y - row_h, sum(colw) - 50 * mm, row_h, stroke=1, fill=1)
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 9)
    labels = ["DATA", "INÍCIO", "FIM", "TOTAL HORA"]
    cw = (sum(colw) - 50 * mm) / 4
    for i, l in enumerate(labels):
        c.drawCentredString(x + 50 * mm + cw * (i + 0.5), y - 6 * mm, l)

    # linhas extras (original)
    c.setFillColor(colors.white)
    for i in range(6):
        yy = y - row_h * (i + 1)
        c.rect(x, yy - row_h, sum(colw), row_h, stroke=1, fill=0)

    c.showPage()
    c.save()
