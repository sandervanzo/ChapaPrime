# ============================
# FILE: app/tabs/planner/view.py
# ============================
from __future__ import annotations

from typing import List, Dict, Optional, Tuple

from PySide6 import QtWidgets
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QGroupBox, QLabel, QComboBox, QDoubleSpinBox,
    QLineEdit, QPushButton, QGraphicsView, QSizePolicy,
    QStackedWidget, QTableWidget, QCheckBox, QSplitter, QSpinBox
)
from PySide6.QtGui import QPainter, QPen, QBrush, QColor, QFont, QImage, QCursor
from PySide6.QtCore import Qt, QRectF, QPointF, QObject, Signal


def _mm_color(hex_str: str, alpha: int = 255) -> QColor:
    c = QColor(hex_str)
    c.setAlpha(alpha)
    return c


class PlannerSignals(QObject):
    pieceSelected = Signal(str, int)
    pieceResized = Signal(str, int)


class EditablePieceItem(QtWidgets.QGraphicsRectItem):
    HANDLE_W = 8.0

    def __init__(self, piece: Dict, ppmm: float, signals: PlannerSignals):
        super().__init__()
        self.signals = signals
        self.ppmm = ppmm
        self.piece = piece
        self.setRect(QRectF(piece["x"] * ppmm, piece["y"] * ppmm, piece["w"] * ppmm, piece["h"] * ppmm))
        self.setBrush(QBrush(_mm_color(piece.get("color", "#3ddc97"), 220)))
        self.setPen(Qt.NoPen)
        self.setFlag(QtWidgets.QGraphicsItem.ItemIsSelectable, True)
        self.setAcceptedMouseButtons(Qt.LeftButton)
        self.setAcceptHoverEvents(True)

        self._dragging = False
        self.font = QFont()
        self.font.setPointSizeF(9.0)
        self.text = None

    def on_added_to_scene(self):
        self.update_label()

    def update_label(self):
        if self.scene() is None:
            return
        if self.text is not None:
            try:
                self.scene().removeItem(self.text)
            except Exception:
                pass
            self.text = None
        if self.rect().width() > 28:
            lbl = f"{int(self.piece.get('w', 0))}"
            self.text = self.scene().addText(lbl, self.font)
            self.text.setDefaultTextColor(_mm_color("#d6dcff"))
            br = self.text.boundingRect()
            r = self.rect()
            self.text.setZValue(self.zValue() + 1)
            self.text.setPos(r.left() + (r.width() - br.width()) / 2, r.top() + (r.height() - br.height()) / 2)

    def hoverMoveEvent(self, event):
        if self._on_handle(event.pos()):
            self.setCursor(QCursor(Qt.SizeHorCursor))
        else:
            self.setCursor(QCursor(Qt.ArrowCursor))
        super().hoverMoveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.signals.pieceSelected.emit(self.piece["id"], int(self.piece["w"]))
            if self._on_handle(event.pos()):
                self._dragging = True
                self._drag_start_x = event.scenePos().x()
                self._orig_w = self.rect().width()
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._dragging:
            dx = event.scenePos().x() - self._drag_start_x
            new_w_px = max(10.0, self._orig_w + dx)

            min_end_px = self.piece["min_end_mm"] * self.ppmm
            max_end_px = self.piece["max_end_mm"] * self.ppmm
            left_px = self.rect().left()
            new_end_px = min(max(left_px + new_w_px, min_end_px), max_end_px)
            new_w_px = new_end_px - left_px

            r = self.rect()
            r.setWidth(new_w_px)
            self.setRect(r)
            self.piece["w"] = int(round(new_w_px / self.ppmm))
            self.update_label()
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._dragging:
            self._dragging = False
            self.signals.pieceResized.emit(self.piece["id"], int(self.piece["w"]))
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def paint(self, painter, option, widget=None):
        super().paint(painter, option, widget)
        r = self.rect()
        handle_rect = QRectF(r.right() - self.HANDLE_W, r.top() + r.height() * 0.25, self.HANDLE_W, r.height() * 0.5)
        painter.setBrush(QBrush(_mm_color("#ffffff", 70)))
        painter.setPen(Qt.NoPen)
        painter.drawRect(handle_rect)
        if self.isSelected():
            pen = QPen(_mm_color("#9ec1ff"))
            pen.setCosmetic(True)
            pen.setWidthF(2.0)
            painter.setPen(pen)
            painter.setBrush(Qt.NoBrush)
            painter.drawRect(r)

    def _on_handle(self, pos: QPointF) -> bool:
        r = self.rect()
        return QRectF(r.right() - self.HANDLE_W, r.top() + r.height() * 0.25, self.HANDLE_W, r.height() * 0.5).contains(pos)

    def set_ppmm(self, ppmm: float):
        factor = ppmm / self.ppmm
        self.ppmm = ppmm
        r = self.rect()
        self.setRect(QRectF(r.left() * factor, r.top() * factor, r.width() * factor, r.height() * factor))
        self.update_label()


class PlannerScene(QtWidgets.QGraphicsScene):
    COL_BG = _mm_color("#0e1220")
    COL_PLATE = _mm_color("#1b2136")
    COL_MARGINS = _mm_color("#7f5af0", 36)
    COL_GAP = _mm_color("#00c2ff", 26)
    COL_KERF = _mm_color("#ffd166")
    COL_GRID = _mm_color("#2a2f45")
    COL_DIM_TXT = _mm_color("#cfd8ff")
    COL_LABEL = _mm_color("#d6dcff")
    COL_WASTE = _mm_color("#e5383b", 40)

    GRID_STEP_MM = 500

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setBackgroundBrush(QBrush(self.COL_BG))
        self.show_grid = True
        self.show_dims = True
        self.show_margins = True
        self.show_labels = True
        self.show_kerf = True
        self.edit_mode = False
        self.ppmm: float = 0.3
        self.signals = PlannerSignals()
        self._piece_items: Dict[str, EditablePieceItem] = {}

    def render_layout(
        self,
        plate_w_mm: float,
        plate_h_mm: float,
        kerf_mm: float,
        margin_mm: float,
        pieces: List[Dict],
        scraps: Optional[List[Dict]] = None,
        gaps: Optional[List[Dict]] = None,
    ) -> None:
        self.clear()
        self._piece_items.clear()

        pad_px = 120
        plate_rect_px = QRectF(0, 0, plate_w_mm * self.ppmm, plate_h_mm * self.ppmm)
        total_rect_px = plate_rect_px.adjusted(-pad_px, -pad_px, pad_px, pad_px)
        self.setSceneRect(total_rect_px)

        self.addRect(plate_rect_px, QPen(Qt.NoPen), QBrush(self.COL_PLATE)).setZValue(0)

        if self.show_grid:
            self._draw_grid(plate_rect_px, self.GRID_STEP_MM)
        if self.show_margins and margin_mm > 0:
            mx = margin_mm * self.ppmm
            self.addRect(plate_rect_px.adjusted(mx, mx, -mx, -mx), QPen(Qt.NoPen), QBrush(self.COL_MARGINS))

        for p in pieces or []:
            x = float(p.get("x", 0)) * self.ppmm
            y = float(p.get("y", 0)) * self.ppmm
            w = float(p.get("w", 0)) * self.ppmm
            h = float(p.get("h", 0)) * self.ppmm
            color = p.get("color", "#3ddc97")
            if self.edit_mode:
                item = EditablePieceItem({**p, "color": color}, self.ppmm, self.signals)
                self.addItem(item)
                item.setZValue(2)
                item.on_added_to_scene()
                self._piece_items[p["id"]] = item
            else:
                r = self.addRect(QRectF(x, y, w, h), QPen(Qt.NoPen), QBrush(_mm_color(color, 220)))
                r.setZValue(2)
                if self.show_labels and w > 28:
                    txt = self.addText(str(p.get("label", f"{int(p.get('w', 0))}×{int(p.get('h', 0))}")), QFont("", 9))
                    txt.setDefaultTextColor(self.COL_LABEL)
                    br = txt.boundingRect()
                    txt.setPos(x + (w - br.width()) / 2, y + (h - br.height()) / 2)
                    txt.setZValue(3)

        for g in gaps or []:
            x = float(g.get("x", 0)) * self.ppmm
            y = float(g.get("y", 0)) * self.ppmm
            w = float(g.get("w", 0)) * self.ppmm
            h = float(g.get("h", 0)) * self.ppmm
            self.addRect(QRectF(x, y, w, h), QPen(Qt.NoPen), QBrush(self.COL_GAP)).setZValue(1)

        if self.show_kerf and kerf_mm > 0 and (pieces or gaps):
            pen = QPen(self.COL_KERF)
            pen.setWidthF(max(1.0, kerf_mm * self.ppmm))
            pen.setCosmetic(False)
            nob = QBrush(Qt.NoBrush)
            for p in pieces or []:
                x = float(p.get("x", 0)) * self.ppmm
                y = float(p.get("y", 0)) * self.ppmm
                w = float(p.get("w", 0)) * self.ppmm
                h = float(p.get("h", 0)) * self.ppmm
                self.addRect(QRectF(x, y, w, h), pen, nob)
            for g in gaps or []:
                x = float(g.get("x", 0)) * self.ppmm
                y = float(g.get("y", 0)) * self.ppmm
                w = float(g.get("w", 0)) * self.ppmm
                h = float(g.get("h", 0)) * self.ppmm
                self.addRect(QRectF(x, y, w, h), pen, nob)

        for s in scraps or []:
            x = float(s.get("x", 0)) * self.ppmm
            y = float(s.get("y", 0)) * self.ppmm
            w = float(s.get("w", 0)) * self.ppmm
            h = float(s.get("h", 0)) * self.ppmm
            self.addRect(QRectF(x, y, w, h), QPen(Qt.NoPen), QBrush(self.COL_WASTE)).setZValue(1)

        if self.show_dims:
            self._draw_dimensions(plate_rect_px, plate_w_mm, plate_h_mm)

    def _draw_grid(self, plate_rect_px: QRectF, step_mm: float) -> None:
        step_px = step_mm * self.ppmm
        pen = QPen(self.COL_GRID)
        pen.setCosmetic(True)
        pen.setWidthF(1.0)
        x = 0.0
        while x <= plate_rect_px.width() + 1:
            self.addLine(x, 0, x, plate_rect_px.height(), pen).setZValue(-1)
            x += step_px
        y = 0.0
        while y <= plate_rect_px.height() + 1:
            self.addLine(0, y, plate_rect_px.width(), y, pen).setZValue(-1)
            y += step_px

    def _draw_dimensions(self, plate_rect_px: QRectF, w_mm: float, h_mm: float) -> None:
        pen = QPen(self.COL_DIM_TXT)
        pen.setCosmetic(True)
        pen.setWidthF(1.0)
        font = QFont()
        font.setPointSizeF(9.5)

        # Horizontal (topo)
        y = plate_rect_px.top() - 30
        self.addLine(plate_rect_px.left(), y, plate_rect_px.right(), y, pen)
        self.addLine(plate_rect_px.left(), y - 6, plate_rect_px.left(), y + 6, pen)
        self.addLine(plate_rect_px.right(), y - 6, plate_rect_px.right(), y + 6, pen)
        txt_h = self.addText(f"{int(w_mm)} mm", font)
        txt_h.setDefaultTextColor(self.COL_DIM_TXT)
        tx = plate_rect_px.left() + (plate_rect_px.width() - txt_h.boundingRect().width()) / 2
        txt_h.setPos(tx, y - 18)

        # Vertical (esquerda)
        x = plate_rect_px.left() - 30
        self.addLine(x, plate_rect_px.top(), x, plate_rect_px.bottom(), pen)
        self.addLine(x - 6, plate_rect_px.top(), x + 6, plate_rect_px.top(), pen)
        self.addLine(x - 6, plate_rect_px.bottom(), x + 6, plate_rect_px.bottom(), pen)
        txt_v = self.addText(f"{int(h_mm)} mm", font)
        txt_v.setDefaultTextColor(self.COL_DIM_TXT)
        txt_v.setRotation(-90)
        vx = x - 18
        vy = plate_rect_px.top() + (plate_rect_px.height() + txt_v.boundingRect().width()) / 2
        txt_v.setPos(vx, vy)

    def apply_ppmm_to_edit_items(self):
        for it in self._piece_items.values():
            it.set_ppmm(self.ppmm)


class PlannerView(QWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setMinimumSize(1100, 700)

        self.setStyleSheet("""
            QGroupBox { margin-top: 22px; border: 1px solid #2a2f45; border-radius: 8px; padding: 8px; }
            QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top left; left: 10px; padding: 0 8px; font-weight: 600; }
            QPushButton { padding: 6px 10px; border-radius: 8px; }
            QPushButton#primary { background: #5468ff; color: white; }
            QPushButton#primary:disabled { background: #2f3566; color: #9aa3ff; }
            QPushButton#ghost { background: #2b3047; color: #d6dcff; }
            QLineEdit, QComboBox, QDoubleSpinBox, QSpinBox { min-height: 28px; }
            QTableWidget { background: #1a1f33; gridline-color: #2a2f45; border-radius: 6px; }
            QHeaderView::section { background: #20263c; padding: 6px; border: 0; font-weight: 600; }
            QLabel#muted { color:#91a0ca; }
        """)

        splitter = QSplitter(Qt.Vertical, self)

        top = QWidget()
        main = QVBoxLayout(top)
        main.setContentsMargins(10, 8, 10, 8)
        main.setSpacing(8)

        box_params = QGroupBox("Chapa, Material e Parâmetros")
        grid = QGridLayout(box_params)
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(8)

        grid.addWidget(QLabel("Chapa:"), 0, 0)
        self.cb_chapa = QComboBox()
        self.cb_chapa.addItems(["1200 x 3000", "1200 x 6000", "1000 x 6000"])
        self.cb_chapa.setEditable(True)
        self.cb_chapa.setInsertPolicy(QComboBox.NoInsert)
        self.cb_chapa.lineEdit().setPlaceholderText("Ex.: 1250 x 3100")
        grid.addWidget(self.cb_chapa, 0, 1)

        self.sp_kerf = QDoubleSpinBox()
        self.sp_kerf.setDecimals(2)
        self.sp_kerf.setSuffix(" mm")
        self.sp_kerf.setMinimum(0.0)
        self.sp_kerf.setValue(3.00)

        self.sp_margem = QDoubleSpinBox()
        self.sp_margem.setDecimals(1)
        self.sp_margem.setSuffix(" mm")
        self.sp_margem.setMinimum(0.0)
        self.sp_margem.setValue(8.0)

        self.sp_folga = QDoubleSpinBox()
        self.sp_folga.setDecimals(1)
        self.sp_folga.setSuffix(" mm")
        self.sp_folga.setMinimum(0.0)
        self.sp_folga.setValue(44.0)

        grid.addWidget(QLabel("Kerf:"), 1, 0)
        grid.addWidget(self.sp_kerf, 1, 1)
        grid.addWidget(QLabel("Margem:"), 1, 2)
        grid.addWidget(self.sp_margem, 1, 3)
        grid.addWidget(QLabel("Folga:"), 1, 4)
        grid.addWidget(self.sp_folga, 1, 5)

        grid.addWidget(QLabel("Composição:"), 2, 0)

        comp_row = QHBoxLayout()
        comp_row.setSpacing(6)

        self.stacked_comp = QStackedWidget()

        page_text = QtWidgets.QWidget()
        lt = QVBoxLayout(page_text)
        lt.setContentsMargins(0, 0, 0, 0)
        self.ed_comp = QLineEdit("1x600, 2x400, 3x240")
        self.ed_comp.setPlaceholderText("Ex.: 1x600, 2x400, 3x240")
        lt.addWidget(self.ed_comp)
        self.stacked_comp.addWidget(page_text)

        page_tbl = QtWidgets.QWidget()
        lb = QVBoxLayout(page_tbl)
        lb.setContentsMargins(0, 0, 0, 0)
        self.tw_comp = QTableWidget(0, 2)
        self.tw_comp.setHorizontalHeaderLabels(["Qtd", "Comprimento (mm)"])
        self.tw_comp.horizontalHeader().setStretchLastSection(True)
        self.tw_comp.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.tw_comp.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        lb.addWidget(self.tw_comp)
        self.stacked_comp.addWidget(page_tbl)

        comp_row.addWidget(self.stacked_comp, 1)

        self.bt_comp_mode = QPushButton("Tabela ↔ Texto")
        self.bt_comp_mode.setObjectName("ghost")
        self.bt_comp_add = QPushButton("+")
        self.bt_comp_add.setObjectName("ghost")
        self.bt_comp_del = QPushButton("−")
        self.bt_comp_del.setObjectName("ghost")

        comp_row.addWidget(self.bt_comp_mode)
        comp_row.addWidget(self.bt_comp_add)
        comp_row.addWidget(self.bt_comp_del)
        comp_row.addStretch(1)

        grid.addLayout(comp_row, 2, 1, 1, 5)

        self.lbl_hint = QLabel("")
        self.lbl_hint.setStyleSheet("color:#ff8080; font-size:12px;")
        grid.addWidget(self.lbl_hint, 3, 1, 1, 5)
        main.addWidget(box_params)

        tool = QHBoxLayout()
        tool.setSpacing(8)
        self.bt_zoom_in = QPushButton("+")
        self.bt_zoom_in.setObjectName("ghost")
        self.bt_zoom_out = QPushButton("−")
        self.bt_zoom_out.setObjectName("ghost")
        self.bt_zoom_fit = QPushButton("Ajustar")
        self.bt_zoom_fit.setObjectName("ghost")
        self.bt_scale_100 = QPushButton("100%")
        self.bt_scale_100.setObjectName("ghost")
        self.bt_edit_mode = QPushButton("Editar")
        self.bt_edit_mode.setCheckable(True)
        self.bt_edit_mode.setObjectName("ghost")
        tool.addWidget(self.bt_zoom_in)
        tool.addWidget(self.bt_zoom_out)
        tool.addWidget(self.bt_zoom_fit)
        tool.addWidget(self.bt_scale_100)
        tool.addWidget(self.bt_edit_mode)

        tool.addSpacing(8)
        tool.addWidget(QLabel("Comprimento (mm):"))
        self.sp_piece_len = QSpinBox()
        self.sp_piece_len.setRange(1, 100000)
        self.sp_piece_len.setValue(0)
        self.sp_piece_len.setEnabled(False)
        tool.addWidget(self.sp_piece_len)

        tool.addSpacing(8)
        self.lbl_summary = QLabel("Peças: 0   •   Chapas: 0   •   Aproveitamento: 0,0%   •   Sobra: 0 mm")
        self.lbl_summary.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        tool.addWidget(self.lbl_summary, 1)

        self.bt_layout = QPushButton("Gerar Layout")
        self.bt_layout.setObjectName("primary")
        self.bt_pdf = QPushButton("Exportar PDF (layout)")
        self.bt_panel_toggle = QPushButton("Ocultar painel")
        self.bt_panel_toggle.setObjectName("ghost")
        tool.addWidget(self.bt_layout)
        tool.addWidget(self.bt_pdf)
        tool.addWidget(self.bt_panel_toggle)
        main.addLayout(tool)

        mini = QHBoxLayout()
        mini.setSpacing(8)
        self.cb_grid = QCheckBox("Grade")
        self.cb_grid.setChecked(True)
        self.cb_dims = QCheckBox("Cotas")
        self.cb_dims.setChecked(True)
        self.cb_margins = QCheckBox("Margens")
        self.cb_margins.setChecked(True)
        self.cb_labels = QCheckBox("Rótulos")
        self.cb_labels.setChecked(True)
        self.cb_kerf = QCheckBox("Kerf")
        self.cb_kerf.setChecked(True)
        mini.addWidget(self.cb_grid)
        mini.addWidget(self.cb_dims)
        mini.addWidget(self.cb_margins)
        mini.addWidget(self.cb_labels)
        mini.addWidget(self.cb_kerf)
        mini.addSpacing(12)
        mini.addWidget(QLabel("Escala (px/mm):"))
        self.sp_scale = QDoubleSpinBox()
        self.sp_scale.setDecimals(3)
        self.sp_scale.setRange(0.02, 5.0)
        self.sp_scale.setSingleStep(0.01)
        self.sp_scale.setValue(0.30)
        mini.addWidget(self.sp_scale)
        mini.addStretch(1)
        muted = QLabel("Dica: ‘Ajustar’ para enquadrar • F11 tela cheia")
        muted.setObjectName("muted")
        mini.addWidget(muted)
        main.addLayout(mini)

        bottom = QWidget()
        bot_l = QVBoxLayout(bottom)
        bot_l.setContentsMargins(10, 0, 10, 10)
        self.gv = QGraphicsView()
        self.gv.setObjectName("preview")
        self.gv.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.gv.setRenderHints(QPainter.Antialiasing | QPainter.TextAntialiasing)
        self.gv.setResizeAnchor(QGraphicsView.AnchorViewCenter)
        self.gv.setDragMode(QGraphicsView.ScrollHandDrag)
        self.gv.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        bot_l.addWidget(self.gv, 1)

        self.scene = PlannerScene()
        self.gv.setScene(self.scene)

        splitter.addWidget(top)
        splitter.addWidget(bottom)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        lay_root = QVBoxLayout(self)
        lay_root.setContentsMargins(0, 0, 0, 0)
        lay_root.addWidget(splitter, 1)
        self._splitter = splitter
        self._panel_widget = top

        self.bt_zoom_in.clicked.connect(lambda: self.gv.scale(1.15, 1.15))
        self.bt_zoom_out.clicked.connect(lambda: self.gv.scale(1 / 1.15, 1 / 1.15))
        self.bt_zoom_fit.clicked.connect(self.fit_preview)
        self.bt_scale_100.clicked.connect(lambda: self._apply_scale(0.30))
        self.bt_panel_toggle.clicked.connect(self.toggle_panel)

        self.cb_grid.toggled.connect(self._apply_layer_toggles)
        self.cb_dims.toggled.connect(self._apply_layer_toggles)
        self.cb_margins.toggled.connect(self._apply_layer_toggles)
        self.cb_labels.toggled.connect(self._apply_layer_toggles)
        self.cb_kerf.toggled.connect(self._apply_layer_toggles)
        self.sp_scale.valueChanged.connect(self._apply_scale)

        self.bt_edit_mode.toggled.connect(self._toggle_edit_mode)
        self.scene.signals.pieceSelected.connect(self._on_piece_selected)
        self.scene.signals.pieceResized.connect(self._on_piece_resized)
        self._suppress_spin_signal = False
        self._selected_piece_id: Optional[str] = None
        self.sp_piece_len.valueChanged.connect(self._on_piece_len_spin)

        self._last_args: Optional[Tuple] = None

    def render_preview(self, plate_w_mm, plate_h_mm, kerf_mm, margin_mm,
                       pieces: List[Dict], scraps: Optional[List[Dict]] = None,
                       gaps: Optional[List[Dict]] = None, fit_after: bool = True) -> None:
        self._last_args = (plate_w_mm, plate_h_mm, kerf_mm, margin_mm, pieces, scraps, gaps)
        self.scene.render_layout(*self._last_args)
        if self.bt_edit_mode.isChecked():
            self.scene.apply_ppmm_to_edit_items()
        if fit_after:
            self.fit_preview()

    def fit_preview(self) -> None:
        if self.gv.scene():
            self.gv.fitInView(self.gv.scene().sceneRect(), Qt.KeepAspectRatio)

    def export_preview_png(self, path: str) -> bool:
        if not self.gv.scene():
            return False
        rect = self.gv.scene().sceneRect()
        if rect.width() * rect.height() > 100_000_000:
            return False
        img = QImage(int(rect.width()), int(rect.height()), QImage.Format_ARGB32)
        img.fill(Qt.transparent)
        painter = QPainter(img)
        self.gv.scene().render(painter)
        painter.end()
        return img.save(path)

    def _apply_layer_toggles(self) -> None:
        self.scene.show_grid = self.cb_grid.isChecked()
        self.scene.show_dims = self.cb_dims.isChecked()
        self.scene.show_margins = self.cb_margins.isChecked()
        self.scene.show_labels = self.cb_labels.isChecked()
        self.scene.show_kerf = self.cb_kerf.isChecked()
        if self._last_args:
            self.scene.render_layout(*self._last_args)

    def _apply_scale(self, value: float) -> None:
        self.scene.ppmm = float(value)
        self.sp_scale.blockSignals(True)
        self.sp_scale.setValue(self.scene.ppmm)
        self.sp_scale.blockSignals(False)
        if self._last_args:
            self.scene.render_layout(*self._last_args)
            if self.bt_edit_mode.isChecked():
                self.scene.apply_ppmm_to_edit_items()
            self.fit_preview()

    def toggle_panel(self):
        if self._panel_widget.isVisible():
            self._panel_widget.setVisible(False)
            self.bt_panel_toggle.setText("Mostrar painel")
        else:
            self._panel_widget.setVisible(True)
            self.bt_panel_toggle.setText("Ocultar painel")

    def _toggle_edit_mode(self, on: bool):
        self.scene.edit_mode = on
        if self._last_args:
            self.scene.render_layout(*self._last_args)
            if on:
                self.scene.apply_ppmm_to_edit_items()
        self._selected_piece_id = None
        self.sp_piece_len.setEnabled(False)

    def _on_piece_selected(self, piece_id: str, length_mm: int):
        self._selected_piece_id = piece_id
        self._suppress_spin_signal = True
        self.sp_piece_len.setValue(int(length_mm))
        self._suppress_spin_signal = False
        self.sp_piece_len.setEnabled(True)

    def _on_piece_resized(self, piece_id: str, new_len_mm: int):
        pass

    def _on_piece_len_spin(self, val: int):
        if self._suppress_spin_signal or not self.bt_edit_mode.isChecked() or not self._selected_piece_id:
            return
        self.scene.signals.pieceResized.emit(self._selected_piece_id, int(val))
