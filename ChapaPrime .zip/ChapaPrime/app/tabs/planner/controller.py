# ============================
# FILE: app/tabs/planner/controller.py
# ============================
from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from typing import List, Tuple, Dict, Any, Optional

from PySide6 import QtWidgets
from PySide6.QtWidgets import QGraphicsScene, QTableWidgetItem
from PySide6.QtGui import QColor
from PySide6.QtCore import Qt

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.lib import colors

from app.tabs.planner.view import PlannerView  # type: ignore


# ---------------- Models ----------------
@dataclass
class Piece:
    length: float
    start: float
    index: int
    uid: str  # id único para edição


@dataclass
class SheetPlan:
    pieces: List[Piece]
    used_len: float
    last_pos: float


# ---------------- Parse helpers ----------
def parse_chapa(text: str) -> Tuple[int, int]:
    """
    Extrai (largura_mm, comprimento_mm) do texto 'LARGURA x COMPRIMENTO'.
    Aceita '1200 x 3000', '1200x3000', etc.
    """
    nums = re.findall(r'\d+', text or "")
    if len(nums) >= 2:
        return int(nums[0]), int(nums[1])
    raise ValueError("Formato de chapa inválido. Use 'LARGURA x COMPRIMENTO' (mm).")


def parse_composition(text: str) -> List[Tuple[int, int]]:
    """
    Converte texto como '1x600, 2x400; 3x240' para [(1,600), (2,400), (3,240)].
    - tolera ×/X -> x
    - separadores: vírgula, ponto e vírgula, barra, pipe
    - ignora espaços
    """
    s = str(text or "")
    s = s.replace("×", "x").replace("X", "x")
    s = re.sub(r"[;/\\|]+", ",", s)
    s = re.sub(r"\s+", "", s)
    if not s:
        return []
    parts = [p for p in s.split(",") if p]
    out: List[Tuple[int, int]] = []
    for p in parts:
        m = re.fullmatch(r"(\d+)x(\d+)", p)
        if not m:
            raise ValueError(f"Composição inválida: '{p}'. Use 'NxL', ex.: 2x400")
        q, L = int(m.group(1)), int(m.group(2))
        if q <= 0 or L <= 0:
            raise ValueError(f"Valores inválidos em '{p}'.")
        out.append((q, L))
    return out


# ---------------- Core planner -----------
def plan_layout_1d(width_mm: int, length_mm: int, kerf: float, margem: float, folga: float,
                   comp: List[Tuple[int, int]]) -> Dict[str, Any]:
    """
    Planeja cortes 1D ao longo do COMPRIMENTO (eixo X), respeitando margem, kerf e folga.
    Retorna um dicionário contendo as chapas, peças posicionadas e métricas.
    """
    # expande e ordena por comprimento decrescente (heurística FFD simples)
    pieces_list: List[int] = []
    for count, L in comp:
        pieces_list.extend([int(L)] * int(count))
    pieces_list.sort(reverse=True)

    sheets: List[SheetPlan] = []
    right_limit = length_mm - margem
    idx_counter = 0

    while pieces_list:
        current = margem
        placed: List[Piece] = []
        used = 0.0
        changed = True
        while changed and pieces_list:
            changed = False
            for i, L in enumerate(pieces_list):
                extra = 0.0 if current == margem else (kerf + folga)
                if current + extra + L <= right_limit + 1e-6:
                    start = current + extra
                    placed.append(Piece(length=L, start=start, index=idx_counter, uid=str(uuid.uuid4())))
                    used += L
                    current = start + L
                    idx_counter += 1
                    pieces_list.pop(i)
                    changed = True
                    break
        sheets.append(SheetPlan(pieces=placed, used_len=used, last_pos=current))

    usable = max(0.0, (length_mm - 2 * margem))
    total_used = sum(s.used_len for s in sheets)
    total_usable = usable * max(1, len(sheets))
    utilization = (total_used / total_usable * 100.0) if total_usable > 0 else 0.0
    waste_total = max(0.0, total_usable - total_used)

    return dict(
        width_mm=width_mm, length_mm=length_mm, kerf=kerf, margem=margem, folga=folga,
        sheets=sheets, total_used=total_used, total_usable=total_usable,
        utilization=utilization, waste_total=waste_total,
        piece_count=sum(c for c, _ in comp),
    )


# ---------------- Controller -------------
class PlannerController:
    def __init__(self, view: PlannerView):
        self.ui = view
        self._last_layout: Optional[Dict[str, Any]] = None

        # --- Conexões UI principais ---
        self.ui.bt_layout.clicked.connect(self.do_layout)
        self.ui.bt_pdf.clicked.connect(self.export_pdf)

        # Chapa: reage tanto à troca do índice quanto ao texto digitado
        self.ui.cb_chapa.currentIndexChanged.connect(self.do_layout)
        self.ui.cb_chapa.currentTextChanged.connect(self.do_layout)

        for sp in (self.ui.sp_kerf, self.ui.sp_margem, self.ui.sp_folga):
            sp.valueChanged.connect(self.do_layout)

        self.ui.ed_comp.returnPressed.connect(self.do_layout)

        self.ui.bt_comp_add.clicked.connect(self._comp_add_row)
        self.ui.bt_comp_del.clicked.connect(self._comp_del_row)
        self.ui.tw_comp.cellChanged.connect(lambda *_: self.do_layout())
        self.ui.bt_comp_mode.clicked.connect(self._toggle_comp_mode)

        # Sinais de edição no preview (drag da “orelha” e spin Comprimento)
        self.ui.scene.signals.pieceResized.connect(self._on_piece_resized_from_scene)

        # Primeira renderização
        self.do_layout()

    # ---------- composição ----------
    def _toggle_comp_mode(self):
        idx = self.ui.stacked_comp.currentIndex()
        if idx == 0:
            try:
                comp = parse_composition(self.ui.ed_comp.text())
            except Exception:
                comp = []
            self._table_from_comp(comp)
            self.ui.stacked_comp.setCurrentIndex(1)
        else:
            comp = self._comp_from_table()
            txt = ", ".join(f"{q}x{L}" for q, L in comp) or "1x600, 2x400, 3x240"
            self.ui.ed_comp.setText(txt)
            self.ui.stacked_comp.setCurrentIndex(0)
        self.do_layout()

    def _comp_add_row(self):
        r = self.ui.tw_comp.rowCount()
        self.ui.tw_comp.insertRow(r)
        self.ui.tw_comp.setItem(r, 0, QTableWidgetItem("1"))
        self.ui.tw_comp.setItem(r, 1, QTableWidgetItem("600"))

    def _comp_del_row(self):
        r = self.ui.tw_comp.currentRow()
        if r >= 0:
            self.ui.tw_comp.removeRow(r)
            self.do_layout()

    def _comp_from_table(self) -> List[Tuple[int, int]]:
        data: List[Tuple[int, int]] = []
        for r in range(self.ui.tw_comp.rowCount()):
            try:
                q = int((self.ui.tw_comp.item(r, 0) or QTableWidgetItem("0")).text())
                L = int((self.ui.tw_comp.item(r, 1) or QTableWidgetItem("0")).text())
            except Exception:
                q, L = 0, 0
            if q > 0 and L > 0:
                data.append((q, L))
        return data

    def _table_from_comp(self, comp: List[Tuple[int, int]]) -> None:
        self.ui.tw_comp.setRowCount(0)
        for q, L in comp:
            r = self.ui.tw_comp.rowCount()
            self.ui.tw_comp.insertRow(r)
            self.ui.tw_comp.setItem(r, 0, QTableWidgetItem(str(q)))
            self.ui.tw_comp.setItem(r, 1, QTableWidgetItem(str(L)))

    # ---------- fluxo principal ----------
    def _error(self, msg: str):
        try:
            QtWidgets.QMessageBox.warning(None, "Planner", msg)
        except Exception:
            pass
        # placeholder simples
        self.ui.lbl_summary.setText(f"⚠ {msg}")
        scene = QGraphicsScene()
        scene.setBackgroundBrush(QColor("#131827"))
        self.ui.gv.setScene(scene)
        t = scene.addSimpleText("Sem layout.")
        br = t.boundingRect()
        t.setPos(20, 20)
        scene.setSceneRect(0, 0, max(320.0, br.width()+40), max(180.0, br.height()+40))
        self.ui.bt_pdf.setEnabled(False)

    def do_layout(self):
        # parse params
        try:
            width_mm, length_mm = parse_chapa(self.ui.cb_chapa.currentText())
            comp = (
                parse_composition(self.ui.ed_comp.text())
                if self.ui.stacked_comp.currentIndex() == 0
                else self._comp_from_table()
            )
            if not comp:
                raise ValueError("Informe a composição (use o texto ou a tabela).")
        except Exception as e:
            return self._error(str(e))

        kerf = float(self.ui.sp_kerf.value())
        margem = float(self.ui.sp_margem.value())
        folga = float(self.ui.sp_folga.value())

        if 2 * margem >= length_mm:
            return self._error("Margem muito grande para o comprimento da chapa.")
        if 2 * margem >= width_mm:
            return self._error("Margem muito grande para a largura da chapa.")

        # planeja
        layout = plan_layout_1d(width_mm, length_mm, kerf, margem, folga, comp)
        self._last_layout = layout

        # preview 2D
        self._draw_preview_2d(layout)

        # resumo
        self._fill_summary(layout)
        self.ui.bt_pdf.setEnabled(True)

    # ---------- preview 2D / edição ----------
    def _draw_preview_2d(self, layout: Dict[str, Any]) -> None:
        """
        Monta as listas para a view desenhar:
        - pieces: retângulos completos no eixo Y (altura útil)
        - gaps: kerf + folgas (faixas)
        - scraps: sobra final à direita
        Também adiciona metadados de edição (id, limites min/max de fim).
        """
        length_mm: float = float(layout['length_mm'])   # X
        width_mm: float  = float(layout['width_mm'])    # Y
        margem: float    = float(layout['margem'])
        folga: float     = float(layout['folga'])
        kerf: float      = float(layout['kerf'])

        inner_h = max(0.0, width_mm - 2.0 * margem)

        sheet_gap = 50.0
        pieces: List[Dict[str, Any]] = []
        gaps:   List[Dict[str, Any]] = []
        scraps: List[Dict[str, Any]] = []

        y_cursor = 0.0
        for sheet in layout['sheets']:
            y_top = y_cursor
            last_piece_end = margem
            for i, p in enumerate(sheet.pieces):
                # separações entre peças
                if i > 0:
                    if kerf > 0:
                        gaps.append({"x": last_piece_end, "y": y_top + margem, "w": kerf, "h": inner_h})
                    if folga > 0:
                        gaps.append({"x": last_piece_end + kerf, "y": y_top + margem, "w": folga, "h": inner_h})

                # limites de edição à direita
                next_start = (sheet.pieces[i+1].start if i+1 < len(sheet.pieces) else (length_mm - margem))
                max_end = next_start  # não deixa invadir a próxima peça (considerando vão)
                min_end = p.start + 10.0  # largura mínima visual de 10 mm

                pieces.append({
                    "id": p.uid,
                    "x": p.start,
                    "y": y_top + margem,
                    "w": p.length,
                    "h": inner_h,
                    "label": f"{int(p.length)}",
                    "min_end_mm": min_end,
                    "max_end_mm": max_end
                })

                last_piece_end = p.start + p.length + folga + kerf

            # sobra final
            tail_start = (sheet.pieces[-1].start + sheet.pieces[-1].length) if sheet.pieces else margem
            tail_len = (length_mm - margem) - tail_start
            if tail_len > 0:
                scraps.append({"x": tail_start, "y": y_top + margem, "w": tail_len, "h": inner_h})

            y_cursor = y_top + width_mm + sheet_gap

        total_plate_h = (len(layout['sheets']) * width_mm) + (max(0, len(layout['sheets']) - 1) * sheet_gap)
        if total_plate_h <= 0:
            total_plate_h = width_mm

        self.ui.render_preview(
            plate_w_mm=length_mm, plate_h_mm=total_plate_h,
            kerf_mm=kerf, margin_mm=margem,
            pieces=pieces, scraps=scraps, gaps=gaps, fit_after=True,
        )

    def _on_piece_resized_from_scene(self, piece_id: str, new_len_mm: int):
        """
        Recebe do preview a edição de comprimento de uma peça.
        Atualiza a composição textual (agrupando por comprimento) e replaneja.
        """
        if not self._last_layout:
            return

        # extrai comprimentos atuais e substitui a peça modificada
        current_lengths: List[int] = []
        for s in self._last_layout["sheets"]:
            for p in s.pieces:
                L = int(round(p.length))
                if p.uid == piece_id:
                    L = int(new_len_mm)
                current_lengths.append(L)

        # agrupa {L: qtd} e monta texto ordenado
        counts: Dict[int, int] = {}
        for L in current_lengths:
            counts[L] = counts.get(L, 0) + 1
        parts = [f"{q}x{L}" for L, q in sorted(((L, q) for L, q in counts.items()), key=lambda t: -t[0])]
        self.ui.ed_comp.setText(", ".join(parts))

        # replaneja imediatamente
        self.do_layout()

    # ---------- resumo ----------
    def _fill_summary(self, layout: Dict[str, Any]):
        pieces = sum(len(s.pieces) for s in layout['sheets'])
        chapas = max(1, len(layout['sheets']))
        util = layout['utilization']
        waste = layout['waste_total']
        usable = layout['total_usable']

        # métricas de corte simples: nº de cortes internos × altura útil
        inner_h = max(0.0, float(layout['width_mm']) - 2.0 * float(layout['margem']))
        internal_cuts = sum(max(0, len(s.pieces) - 1) for s in layout['sheets'])
        total_cut_len_mm = internal_cuts * inner_h
        kerf_total_mm = internal_cuts * float(layout['kerf'])

        self.ui.lbl_summary.setText(
            f"Peças: {pieces}   •   Chapas: {chapas}   •   Aproveitamento: {util:.1f}%   •   "
            f"Sobra: {waste:.0f} mm de {usable:.0f} mm   •   Corte: {total_cut_len_mm:.0f} mm   •   Kerf total: {kerf_total_mm:.1f} mm"
        )

    # ---------- PDF (1D) ----------
    def export_pdf(self):
        # garante layout válido/atual
        self.do_layout()
        if not self.ui.gv.scene():
            return

        try:
            width_mm, length_mm = parse_chapa(self.ui.cb_chapa.currentText())
            comp = (
                parse_composition(self.ui.ed_comp.text())
                if self.ui.stacked_comp.currentIndex() == 0
                else self._comp_from_table()
            )
        except Exception as e:
            return self._error(str(e))

        kerf = float(self.ui.sp_kerf.value())
        margem = float(self.ui.sp_margem.value())
        folga = float(self.ui.sp_folga.value())
        layout = plan_layout_1d(width_mm, length_mm, kerf, margem, folga, comp)

        out, _ = QtWidgets.QFileDialog.getSaveFileName(
            self.ui, "Exportar PDF (layout)", "PLANNER_layout.pdf", "PDF (*.pdf)"
        )
        if not out:
            return

        c = canvas.Canvas(out, pagesize=A4)
        W, H = A4
        margin = 16 * mm
        x = margin
        y = H - margin
        w = W - 2 * margin

        c.setFont("Helvetica-Bold", 12)
        c.drawString(x, y, "Planner — Layout de Corte (1D)")
        y -= 10 * mm
        c.setFont("Helvetica", 10)
        c.drawString(
            x, y,
            f"Chapa: {self.ui.cb_chapa.currentText()}   Kerf: {kerf:.2f} mm   Margem: {margem:.1f} mm   Folga: {folga:.1f} mm"
        )
        y -= 7 * mm
        comp_txt = ", ".join(f"{q}x{L}" for q, L in comp)
        c.drawString(x, y, f"Composição: {comp_txt}")
        y -= 10 * mm

        bar_h = 10 * mm
        gap = 6 * mm
        scale = (w) / float(layout['length_mm'])

        for si, sheet in enumerate(layout['sheets']):
            c.setStrokeColor(colors.HexColor("#3b3f55"))
            c.setFillColor(colors.HexColor("#1c2136"))
            c.rect(x, y - bar_h, layout['length_mm'] * scale, bar_h, stroke=1, fill=1)

            c.setFillColor(colors.HexColor("#7f5af033"))
            m_w = layout['margem'] * scale
            c.rect(x, y - bar_h, m_w, bar_h, stroke=0, fill=1)
            c.rect(x + layout['length_mm'] * scale - m_w, y - bar_h, m_w, bar_h, stroke=0, fill=1)

            palette = ["#4cc9f0", "#f72585", "#b5179e", "#7209b7", "#560bad",
                       "#480ca8", "#3a0ca3", "#3f37c9", "#4895ef", "#4cc9f0"]
            for p in sheet.pieces:
                px = x + p.start * scale
                pw = p.length * scale
                c.setFillColor(colors.HexColor(palette[p.index % len(palette)]))
                c.setStrokeColor(colors.HexColor("#23273d"))
                c.rect(px, y - bar_h + 1 * mm, pw, bar_h - 2 * mm, stroke=1, fill=1)
                c.setFillColor(colors.black)
                c.setFont("Helvetica", 7)
                c.drawCentredString(px + pw / 2, y - bar_h / 2, f"{int(p.length)}")

            c.setStrokeColor(colors.yellow)
            c.setLineWidth(max(0.2, layout['kerf'] * scale))
            for i in range(len(sheet.pieces) - 1):
                px = x + (sheet.pieces[i].start + sheet.pieces[i].length + layout['folga']) * scale
                c.line(px, y - bar_h, px, y)

            c.setFont("Helvetica", 8)
            c.setFillColor(colors.black)
            c.drawString(x, y - bar_h - 3 * mm, f"Chapa {si + 1}")

            y -= (bar_h + gap)
            if y < margin + 40 * mm:
                c.showPage()
                y = H - margin

        c.setFont("Helvetica-Bold", 10)
        pieces = sum(len(s.pieces) for s in layout['sheets'])
        c.drawString(
            x, y - 5 * mm,
            f"Aproveitamento: {layout['utilization']:.1f}%   |   Peças: {pieces}   |   Chapas: {len(layout['sheets'])}"
        )
        c.showPage()
        c.save()

        QtWidgets.QMessageBox.information(self.ui, "Exportar", f"PDF do layout gerado com sucesso:\n{out}")
