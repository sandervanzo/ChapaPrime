from PySide6 import QtWidgets
from PySide6.QtWidgets import (
    QMessageBox, QTableWidgetItem, QCheckBox, QWidget, QHBoxLayout
)
from PySide6.QtCore import Qt, QSignalBlocker
from app.tabs.op.view import OpView
import inspect

# cálculos / PDF
# -> usa services.calc com densidade do config (fallback 8000)
try:
    from services.calc import calc_blank_mm, peso_peca_kg_cfg as peso_peca_kg
except Exception:
    # fallbacks simples (caso ainda não exista services/calc.py)
    def calc_blank_mm(alma, mesa, enrij, esp, n):
        alma=float(alma or 0); mesa=float(mesa or 0); enrij=float(enrij or 0); esp=float(esp or 0); n=int(n or 0)
        return max(0, round(alma + 2*mesa + 2*enrij - 2*esp*n))
    def peso_peca_kg(esp_mm, blank_mm, compr_mm, densidade_kg_m3=8000.0):
        m=1000.0; return (esp_mm/m)*(blank_mm/m)*(compr_mm/m)*float(densidade_kg_m3)

try:
    from services.pdf import export_op_dobra_pdf
except Exception:
    export_op_dobra_pdf = None

# índices das colunas na tabela
C_ITEM, C_QTD, C_PERFIL, C_REFDESC, C_ALMA, C_MESA, C_ENRIJ, C_ESP, C_BLANK, C_COMPR, C_PC, C_TOT, C_D, C_E, C_R = range(15)

def _fmt(v, dec=2):
    try:
        return f"{float(v):,.{dec}f}".replace(",", "X").replace(".", ",").replace("X", ".")
    except Exception:
        return str(v)

def _to_float(s, default=0.0):
    if s is None: return float(default)
    try:
        return float(str(s).replace(".", "").replace(",", "."))
    except Exception:
        return float(default)

class OpController:
    """Controlador da aba Dobra (OP)."""
    def __init__(self, view: OpView):
        self.v = view

        # conexões
        self.v.bt_add.clicked.connect(self.add_or_update)
        self.v.bt_clear.clicked.connect(self.clear_form)
        self.v.bt_del.clicked.connect(self.remove_selected)
        self.v.bt_pdf.clicked.connect(self.export_pdf)

        # tabela: seleção → carrega no formulário
        self.v.table.itemSelectionChanged.connect(self.load_selected_into_form)

        # total inicial
        self._recalc_total()

    # ---------------- formulário ----------------
    def clear_form(self):
        self.v.q_perfil.setCurrentIndex(0)
        self.v.q_ref.clear()
        self.v.q_alma.setValue(0)
        self.v.q_mesa.setValue(0)
        self.v.q_enrij.setValue(0)
        self.v.q_esp.setValue(6.35)
        self.v.q_compr.setValue(6000)
        self.v.q_quant.setValue(1)
        self.v.q_blank_manual.setChecked(False)
        self.v.q_blank.setValue(0)
        self.v.q_d.setChecked(False)
        self.v.q_e.setChecked(False)
        self.v.q_r.setChecked(False)

    def _read_form(self):
        return dict(
            perfil = self.v.q_perfil.currentText(),
            ref    = self.v.q_ref.text().strip(),
            alma   = int(self.v.q_alma.value()),
            mesa   = int(self.v.q_mesa.value()),
            enrij  = int(self.v.q_enrij.value()),
            esp    = float(self.v.q_esp.value()),
            compr  = int(self.v.q_compr.value()),
            quant  = int(self.v.q_quant.value()),
            blank_is_manual = bool(self.v.q_blank_manual.isChecked()),
            blank  = int(self.v.q_blank.value()),
            d = self.v.q_d.isChecked(),
            e = self.v.q_e.isChecked(),
            r = self.v.q_r.isChecked(),
        )

    # ---------------- tabela ----------------
    def _set_checkbox_cell(self, row, col, checked: bool):
        box = QCheckBox()
        box.setChecked(checked)
        cont = QWidget()
        lay = QHBoxLayout(cont); lay.setContentsMargins(0,0,0,0); lay.addWidget(box, alignment=Qt.AlignCenter)
        self.v.table.setCellWidget(row, col, cont)

    def _set_text(self, row, col, text: str, center=True):
        it = QTableWidgetItem(text)
        if center: it.setTextAlignment(Qt.AlignCenter)
        self.v.table.setItem(row, col, it)

    def add_or_update(self):
        data = self._read_form()
        n_dobras = int(self.v.sp_dobras.value() or 0)

        # BLANK automático (a menos que o usuário marque manual)
        if data["blank_is_manual"] and data["blank"] > 0:
            blank = data["blank"]
        else:
            blank = calc_blank_mm(data["alma"], data["mesa"], data["enrij"], data["esp"], n_dobras)

        # Peso usa densidade do config (services.calc.peso_peca_kg_cfg)
        peso_pc = peso_peca_kg(data["esp"], blank, data["compr"])
        peso_tot = peso_pc * data["quant"]

        row = self.v.table.currentRow()
        is_update = row >= 0
        if not is_update:
            row = self.v.table.rowCount()
            with QSignalBlocker(self.v.table):
                self.v.table.insertRow(row)
                self._set_text(row, C_ITEM, str(row + 1))

        with QSignalBlocker(self.v.table):
            self._set_text(row, C_QTD,   str(data["quant"]))
            self._set_text(row, C_PERFIL, data["perfil"])
            self._set_text(row, C_REFDESC, data["ref"])
            self._set_text(row, C_ALMA,  str(data["alma"]))
            self._set_text(row, C_MESA,  str(data["mesa"]))
            self._set_text(row, C_ENRIJ, str(data["enrij"]))
            self._set_text(row, C_ESP,   _fmt(data["esp"], 2))
            self._set_text(row, C_BLANK, str(blank))
            self._set_text(row, C_COMPR, str(data["compr"]))
            self._set_text(row, C_PC,    _fmt(peso_pc, 2))
            self._set_text(row, C_TOT,   _fmt(peso_tot, 2))
            self._set_checkbox_cell(row, C_D, data["d"])
            self._set_checkbox_cell(row, C_E, data["e"])
            self._set_checkbox_cell(row, C_R, data["r"])

        if is_update:
            self.v.table.selectRow(row)
        else:
            self.clear_form()

        self._recalc_total()

    def remove_selected(self):
        row = self.v.table.currentRow()
        if row < 0:
            return
        self.v.table.removeRow(row)
        with QSignalBlocker(self.v.table):
            for i in range(self.v.table.rowCount()):
                self._set_text(i, C_ITEM, str(i + 1))
        self._recalc_total()

    def load_selected_into_form(self):
        row = self.v.table.currentRow()
        if row < 0:
            return
        g = self.v.table
        self.v.q_perfil.setCurrentText(g.item(row, C_PERFIL).text() if g.item(row, C_PERFIL) else "U")
        self.v.q_ref.setText(g.item(row, C_REFDESC).text() if g.item(row, C_REFDESC) else "")

        def _ival(c): return int(_to_float(g.item(row, c).text() if g.item(row, c) else 0))
        def _fval(c): return float(_to_float(g.item(row, c).text() if g.item(row, c) else 0))

        self.v.q_alma.setValue(_ival(C_ALMA))
        self.v.q_mesa.setValue(_ival(C_MESA))
        self.v.q_enrij.setValue(_ival(C_ENRIJ))
        self.v.q_esp.setValue(_fval(C_ESP))
        self.v.q_compr.setValue(_ival(C_COMPR))
        self.v.q_quant.setValue(_ival(C_QTD))

        self.v.q_blank_manual.setChecked(True)
        self.v.q_blank.setValue(_ival(C_BLANK))

        def _chk(col):
            cont = g.cellWidget(row, col)
            if not cont: return False
            box = cont.findChild(QCheckBox)
            return bool(box and box.isChecked())

        self.v.q_d.setChecked(_chk(C_D))
        self.v.q_e.setChecked(_chk(C_E))
        self.v.q_r.setChecked(_chk(C_R))

    # ---------------- export ----------------
    def export_pdf(self):
        if export_op_dobra_pdf is None:
            QMessageBox.warning(self.v, "Exportar", "Módulo de exportação não encontrado (services/pdf.py).")
            return

        header = dict(
            op=self.v.ed_op.text().strip() or "S/N",
            cliente=self.v.ed_cliente.text().strip(),
            obra=self.v.ed_obra.text().strip(),
            coleta=self.v.ed_coleta.text().strip(),
            entrada=self.v.ed_entrada.date().toString("dd/MM/yyyy"),
            saida=self.v.ed_saida.date().toString("dd/MM/yyyy"),
            dobras=int(self.v.sp_dobras.value() or 0),
        )

        itens = []
        for r in range(self.v.table.rowCount()):
            def _t(c):
                it = self.v.table.item(r, c)
                return it.text() if it else ""
            esp = _to_float(_t(C_ESP))
            blank = int(_to_float(_t(C_BLANK)))
            compr = int(_to_float(_t(C_COMPR)))
            peso_pc = peso_peca_kg(esp, blank, compr)

            def _chk(col):
                cont = self.v.table.cellWidget(r, col)
                if not cont: return False
                box = cont.findChild(QCheckBox)
                return bool(box and box.isChecked())

            itens.append(dict(
                item = int(_to_float(_t(C_ITEM))),
                quant = int(_to_float(_t(C_QTD))),
                perfil = _t(C_PERFIL),
                refdesc = _t(C_REFDESC),
                alma = int(_to_float(_t(C_ALMA))),
                mesa = int(_to_float(_t(C_MESA))),
                enrij = int(_to_float(_t(C_ENRIJ))),
                esp = esp,
                blank = blank,
                compr = compr,
                peso_pc = peso_pc,
                d = _chk(C_D), e = _chk(C_E), r = _chk(C_R),
            ))

        fn, _ = QtWidgets.QFileDialog.getSaveFileName(self.v, "Salvar OP (PDF)", "OP_DOBRA_premium.pdf", "PDF (*.pdf)")
        if not fn:
            return

        try:
            # Compatibilidade: com ou sem parâmetro densidade_kg_m3
            params = inspect.signature(export_op_dobra_pdf).parameters
            if "densidade_kg_m3" in params:
                export_op_dobra_pdf(fn, header, itens, densidade_kg_m3=8000.0)
            else:
                export_op_dobra_pdf(fn, header, itens)
            QMessageBox.information(self.v, "Exportar", "PDF gerado com sucesso.")
        except Exception as e:
            QMessageBox.critical(self.v, "Exportar", f"Erro ao gerar PDF:\n{e}")

    # ---------------- total ----------------
    def _recalc_total(self):
        total = 0.0
        for r in range(self.v.table.rowCount()):
            it = self.v.table.item(r, C_TOT)
            if it:
                total += _to_float(it.text())
        self.v.lbl_total.setText(f"T. PEÇAS (kg): {_fmt(total,2)}")
