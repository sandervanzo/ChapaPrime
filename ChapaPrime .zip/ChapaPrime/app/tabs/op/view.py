from PySide6 import QtWidgets, QtCore
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QGroupBox, QGridLayout, QLineEdit, QDateEdit,
    QSpinBox, QDoubleSpinBox, QPushButton, QTableWidget, QTableWidgetItem,
    QHBoxLayout, QComboBox, QCheckBox, QLabel
)
from PySide6.QtCore import QDate


class OpView(QWidget):
    """
    Aba Dobra (OP) – com:
      • Cabeçalho (OP, Cliente, Obra, Coleta, Entrada/Saída, Dobras)
      • Formulário de Item (perfil, ref/desc, alma, mesa, enrij, esp, compr, quant, blank manual, D/E/R)
      • Tabela de itens
      • Rodapé com total e exportação
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        main = QVBoxLayout(self)

        # ===== Cabeçalho =====
        gb = QGroupBox("Cabeçalho")
        gl = QGridLayout(gb)

        self.ed_op = QLineEdit()
        self.ed_cliente = QLineEdit()
        self.ed_obra = QLineEdit()
        self.ed_coleta = QLineEdit()

        self.ed_entrada = QDateEdit()
        self.ed_entrada.setDate(QDate.currentDate())
        self.ed_entrada.setCalendarPopup(True)

        self.ed_saida = QDateEdit()
        self.ed_saida.setDate(QDate.currentDate())
        self.ed_saida.setCalendarPopup(True)

        self.sp_dobras = QSpinBox()
        self.sp_dobras.setRange(0, 16)
        self.sp_dobras.setValue(2)

        gl.addWidget(QtWidgets.QLabel("OP:"),      0, 0); gl.addWidget(self.ed_op,       0, 1, 1, 3)
        gl.addWidget(QtWidgets.QLabel("Cliente:"), 0, 4); gl.addWidget(self.ed_cliente,  0, 5, 1, 3)

        gl.addWidget(QtWidgets.QLabel("Obra:"),    1, 0); gl.addWidget(self.ed_obra,     1, 1, 1, 3)
        gl.addWidget(QtWidgets.QLabel("Coleta:"),  1, 4); gl.addWidget(self.ed_coleta,   1, 5, 1, 3)

        gl.addWidget(QtWidgets.QLabel("Dobras (n):"), 2, 0); gl.addWidget(self.sp_dobras, 2, 1)
        gl.addWidget(QtWidgets.QLabel("Entrada:"),    2, 4); gl.addWidget(self.ed_entrada, 2, 5)
        gl.addWidget(QtWidgets.QLabel("Saída:"),      2, 6); gl.addWidget(self.ed_saida,   2, 7)

        main.addWidget(gb)

        # ===== Formulário do Item =====
        gf = QGroupBox("Item")
        fg = QGridLayout(gf)

        self.q_perfil = QComboBox(); self.q_perfil.addItems(["U", "UR", "L", "CART", "Outro"])
        self.q_ref    = QLineEdit()

        def mm_spin():
            s = QSpinBox(); s.setRange(0, 50000); s.setSuffix(" mm"); return s

        self.q_alma  = mm_spin()
        self.q_mesa  = mm_spin()
        self.q_enrij = mm_spin()

        self.q_esp = QDoubleSpinBox(); self.q_esp.setDecimals(2); self.q_esp.setRange(0, 200); self.q_esp.setSuffix(" mm"); self.q_esp.setValue(6.35)
        self.q_compr = mm_spin(); self.q_compr.setRange(0, 20000); self.q_compr.setValue(6000)
        self.q_quant = QSpinBox(); self.q_quant.setRange(1, 999); self.q_quant.setValue(1)

        self.q_blank_manual = QCheckBox("Blank manual")
        self.q_blank = mm_spin(); self.q_blank.setEnabled(False)
        self.q_blank_manual.toggled.connect(self.q_blank.setEnabled)

        self.q_d = QCheckBox("D")
        self.q_e = QCheckBox("E")
        self.q_r = QCheckBox("R")

        r = 0
        fg.addWidget(QtWidgets.QLabel("Perfil"),     r, 0); fg.addWidget(self.q_perfil, r, 1)
        fg.addWidget(QtWidgets.QLabel("Ref/Desc"),   r, 2); fg.addWidget(self.q_ref,    r, 3, 1, 3)

        r += 1
        fg.addWidget(QtWidgets.QLabel("Alma"),       r, 0); fg.addWidget(self.q_alma,   r, 1)
        fg.addWidget(QtWidgets.QLabel("Mesa"),       r, 2); fg.addWidget(self.q_mesa,   r, 3)
        fg.addWidget(QtWidgets.QLabel("Enrij"),      r, 4); fg.addWidget(self.q_enrij,  r, 5)

        r += 1
        fg.addWidget(QtWidgets.QLabel("Esp."),       r, 0); fg.addWidget(self.q_esp,    r, 1)
        fg.addWidget(QtWidgets.QLabel("Compr."),     r, 2); fg.addWidget(self.q_compr,  r, 3)
        fg.addWidget(QtWidgets.QLabel("Quant"),      r, 4); fg.addWidget(self.q_quant,  r, 5)

        r += 1
        fg.addWidget(self.q_blank_manual,            r, 0)
        fg.addWidget(self.q_blank,                   r, 1)
        fg.addWidget(self.q_d,                       r, 2)
        fg.addWidget(self.q_e,                       r, 3)
        fg.addWidget(self.q_r,                       r, 4)

        main.addWidget(gf)

        # ===== Tabela =====
        self.table = QTableWidget(0, 15)
        self.table.setHorizontalHeaderLabels([
            "Item","Quant","Perfil","Ref/Desc","Alma","Mesa","Enrij","Esp(mm)","Blank(mm)",
            "Compr(mm)","Peso Pc(kg)","Peso Tot(kg)","D","E","R"
        ])
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)  # edição só pelo formulário
        main.addWidget(self.table)

        # ===== Rodapé (ações + total) =====
        hb = QHBoxLayout()
        self.bt_add   = QPushButton("Adicionar / Atualizar")
        self.bt_clear = QPushButton("Limpar campos")
        self.bt_del   = QPushButton("Remover Selecionado")
        self.lbl_total = QLabel("T. PEÇAS (kg): 0,00")
        self.bt_pdf   = QPushButton("Exportar OP (PDF)")

        hb.addWidget(self.bt_add)
        hb.addWidget(self.bt_clear)
        hb.addWidget(self.bt_del)
        hb.addStretch(1)
        hb.addWidget(self.lbl_total)
        hb.addStretch(1)
        hb.addWidget(self.bt_pdf)
        main.addLayout(hb)
