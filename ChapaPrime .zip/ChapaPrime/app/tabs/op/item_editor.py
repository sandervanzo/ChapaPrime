from __future__ import annotations
from typing import Callable, Optional, Dict, Any
from PySide6 import QtCore, QtWidgets

# Tenta usar seus serviços oficiais (densidade padrão vinda do config).
try:
    from services.calc import calc_blank_mm as _calc_blank_mm
    from services.calc import peso_peca_kg_cfg as _peso_peca_kg
except Exception:
    def _calc_blank_mm(alma: float, mesa: float, enrij: float, esp: float, n_dobras: int) -> int:
        alma = float(alma or 0); mesa = float(mesa or 0)
        enrij = float(enrij or 0); esp = float(esp or 0); n = int(n_dobras or 0)
        return round(max(0.0, alma + 2*mesa + 2*enrij - 2*esp*n))

    def _peso_peca_kg(esp_mm: float, blank_mm: float, compr_mm: float, densidade_kg_m3: float = 8000.0) -> float:
        m = 1_000.0
        return (esp_mm/m) * (blank_mm/m) * (compr_mm/m) * float(densidade_kg_m3)


class OPItemEditor(QtWidgets.QGroupBox):
    """
    Editor de Item para a aba Dobra (OP).

    Exibe campos:
      perfil, ref/desc, alma, mesa, enrij, esp(mm), compr(mm), quant, blank(manual opcional), flags D/E/R.

    Sinais:
      itemReady(dict) -> emite um dicionário com todos os campos já calculados.
    """
    itemReady = QtCore.Signal(dict)
    cleared   = QtCore.Signal()

    def __init__(self, get_n_dobras: Callable[[], int], parent: Optional[QtWidgets.QWidget] = None):
        super().__init__("Item", parent)
        self.get_n_dobras = get_n_dobras

        self.setFlat(False)
        self.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)

        # Campos
        self.perfil = QtWidgets.QComboBox()
        self.perfil.addItems(["U", "C", "L", "CART", "UR", "Outro"])

        self.refdesc = QtWidgets.QLineEdit()

        self.alma = QtWidgets.QSpinBox(); self.alma.setRange(0, 5000); self.alma.setSuffix(" mm")
        self.mesa = QtWidgets.QSpinBox(); self.mesa.setRange(0, 5000); self.mesa.setSuffix(" mm")
        self.enrij = QtWidgets.QSpinBox(); self.enrij.setRange(0, 5000); self.enrij.setSuffix(" mm")

        self.esp = QtWidgets.QDoubleSpinBox(); self.esp.setDecimals(2); self.esp.setRange(0, 200); self.esp.setValue(6.35); self.esp.setSuffix(" mm")
        self.compr = QtWidgets.QSpinBox(); self.compr.setRange(0, 20000); self.compr.setValue(6000); self.compr.setSuffix(" mm")

        self.quant = QtWidgets.QSpinBox(); self.quant.setRange(1, 999); self.quant.setValue(1)

        self.chk_blank_manual = QtWidgets.QCheckBox("Blank manual")
        self.blank = QtWidgets.QSpinBox(); self.blank.setRange(0, 50000); self.blank.setSuffix(" mm"); self.blank.setEnabled(False)

        self.flag_d = QtWidgets.QCheckBox("D")
        self.flag_e = QtWidgets.QCheckBox("E")
        self.flag_r = QtWidgets.QCheckBox("R")

        # Info calculada
        self.lbl_peso_pc = QtWidgets.QLabel("0,00 kg")
        self.lbl_preview  = QtWidgets.QLabel("")

        # Botões
        self.btn_add = QtWidgets.QPushButton("Adicionar / Atualizar")
        self.btn_clear = QtWidgets.QPushButton("Limpar")

        # Layout
        form = QtWidgets.QGridLayout()
        r = 0
        form.addWidget(QtWidgets.QLabel("Perfil"), r, 0);         form.addWidget(self.perfil, r, 1)
        form.addWidget(QtWidgets.QLabel("Ref/Desc"), r, 2);       form.addWidget(self.refdesc, r, 3, 1, 3)

        r += 1
        form.addWidget(QtWidgets.QLabel("Alma"), r, 0);           form.addWidget(self.alma, r, 1)
        form.addWidget(QtWidgets.QLabel("Mesa"), r, 2);           form.addWidget(self.mesa, r, 3)
        form.addWidget(QtWidgets.QLabel("Enrij"), r, 4);          form.addWidget(self.enrij, r, 5)

        r += 1
        form.addWidget(QtWidgets.QLabel("Esp."), r, 0);           form.addWidget(self.esp, r, 1)
        form.addWidget(QtWidgets.QLabel("Compr."), r, 2);         form.addWidget(self.compr, r, 3)
        form.addWidget(QtWidgets.QLabel("Quant"), r, 4);          form.addWidget(self.quant, r, 5)

        r += 1
        form.addWidget(self.chk_blank_manual, r, 0)
        form.addWidget(self.blank, r, 1)
        form.addWidget(self.flag_d, r, 2)
        form.addWidget(self.flag_e, r, 3)
        form.addWidget(self.flag_r, r, 4)
        form.addWidget(QtWidgets.QLabel("Peso pc"), r, 5)
        r += 1
        form.addWidget(self.lbl_peso_pc, r, 5)

        r += 1
        btns = QtWidgets.QHBoxLayout()
        btns.addWidget(self.btn_add)
        btns.addWidget(self.btn_clear)
        form.addLayout(btns, r, 0, 1, 6)

        self.setLayout(form)

        # Sinais
        for w in (self.alma, self.mesa, self.enrij, self.esp, self.compr, self.quant):
            w.valueChanged.connect(self._recalc)
        self.chk_blank_manual.toggled.connect(self._toggle_blank_manual)
        self.blank.valueChanged.connect(self._recalc)
        self.btn_add.clicked.connect(self._emit_item)
        self.btn_clear.clicked.connect(self.clear)

        self._recalc()

    # APIs públicas ------------------------------------------------------------

    def set_from_row(self, row_data: Dict[str, Any]) -> None:
        """Preenche o editor a partir de dados de uma linha selecionada da tabela."""
        self.perfil.setCurrentText(str(row_data.get("perfil", "U")) or "U")
        self.refdesc.setText(str(row_data.get("refdesc", "")))

        self.alma.setValue(int(float(row_data.get("alma", 0))))
        self.mesa.setValue(int(float(row_data.get("mesa", 0))))
        self.enrij.setValue(int(float(row_data.get("enrij", 0))))
        self.esp.setValue(float(row_data.get("esp", 0)))
        self.compr.setValue(int(float(row_data.get("compr", 0))))
        self.quant.setValue(int(float(row_data.get("quant", 1))))

        manual = bool(row_data.get("blank_is_manual", False))
        self.chk_blank_manual.setChecked(manual)
        self.blank.setValue(int(float(row_data.get("blank", 0))))
        self._toggle_blank_manual(manual)
        self.flag_d.setChecked(bool(row_data.get("d", False)))
        self.flag_e.setChecked(bool(row_data.get("e", False)))
        self.flag_r.setChecked(bool(row_data.get("r", False)))
        self._recalc()

    def clear(self) -> None:
        self.perfil.setCurrentIndex(0)
        self.refdesc.clear()
        self.alma.setValue(0); self.mesa.setValue(0); self.enrij.setValue(0)
        self.esp.setValue(6.35); self.compr.setValue(6000); self.quant.setValue(1)
        self.chk_blank_manual.setChecked(False); self.blank.setValue(0)
        self.flag_d.setChecked(False); self.flag_e.setChecked(False); self.flag_r.setChecked(False)
        self._recalc()
        self.cleared.emit()

    # Internos -----------------------------------------------------------------

    def _toggle_blank_manual(self, checked: bool) -> None:
        self.blank.setEnabled(checked)
        self._recalc()

    def _recalc(self) -> None:
        alma = self.alma.value()
        mesa = self.mesa.value()
        enrij = self.enrij.value()
        esp = self.esp.value()
        compr = self.compr.value()
        n = int(self.get_n_dobras() or 0)

        if self.chk_blank_manual.isChecked():
            blank = self.blank.value()
        else:
            blank = _calc_blank_mm(alma, mesa, enrij, esp, n)
            self.blank.blockSignals(True)
            self.blank.setValue(blank)
            self.blank.blockSignals(False)

        peso_pc = _peso_peca_kg(esp, blank, compr)
        self.lbl_peso_pc.setText(f"{peso_pc:,.2f} kg".replace(",", "X").replace(".", ",").replace("X", "."))

    def _emit_item(self) -> None:
        alma = int(self.alma.value()); mesa = int(self.mesa.value()); enrij = int(self.enrij.value())
        esp = float(self.esp.value()); compr = int(self.compr.value()); quant = int(self.quant.value())
        n = int(self.get_n_dobras() or 0)

        if self.chk_blank_manual.isChecked():
            blank = int(self.blank.value())
            blank_manual = True
        else:
            blank = _calc_blank_mm(alma, mesa, enrij, esp, n)
            blank_manual = False

        peso_pc = _peso_peca_kg(esp, blank, compr)
        d = {
            "perfil": self.perfil.currentText(),
            "refdesc": self.refdesc.text().strip(),
            "alma": alma, "mesa": mesa, "enrij": enrij,
            "esp": esp, "compr": compr, "quant": quant,
            "blank": blank, "blank_is_manual": blank_manual,
            "peso_pc": peso_pc,
            "d": self.flag_d.isChecked(), "e": self.flag_e.isChecked(), "r": self.flag_r.isChecked(),
        }
        self.itemReady.emit(d)
