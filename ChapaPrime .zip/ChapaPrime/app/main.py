# -*- coding: utf-8 -*-
from PySide6 import QtWidgets, QtCore, QtGui
import os, sys
from pathlib import Path

# >>> usa o nome/versão centralizados
from app.app_meta import APP_NAME, APP_VERSION


def _apply_high_dpi():
    """Ativa suporte a High DPI (quando disponível)."""
    try:
        QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling, True)
        QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_UseHighDpiPixmaps, True)
    except Exception:
        pass


def _apply_theme(app: QtWidgets.QApplication):
    """Carrega o tema QSS global, se existir."""
    qss_path = os.path.join(os.path.dirname(__file__), "ui", "theme_dark.qss")
    try:
        with open(qss_path, "r", encoding="utf-8") as f:
            app.setStyleSheet(f.read())
    except Exception:
        # tema é opcional
        pass


def _set_app_meta(app: QtWidgets.QApplication):
    """Define metadados e ícone do app."""
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setOrganizationName("ChapaPrime")

    # procura ícone em PNG/ICO
    root = Path(__file__).resolve().parents[1]
    candidates = [
        root / "resources" / "icons" / "app.png",
        root / "resources" / "icons" / "app.ico",
        Path(__file__).resolve().parent / "resources" / "icons" / "app.png",
        Path(__file__).resolve().parent / "resources" / "icons" / "app.ico",
    ]
    for p in candidates:
        if p.exists():
            app.setWindowIcon(QtGui.QIcon(str(p)))
            break


def _install_excepthook():
    """Mostra um diálogo amigável em erros não tratados."""
    def handler(exc_type, exc, tb):
        import traceback
        msg = "".join(traceback.format_exception(exc_type, exc, tb))
        try:
            QtWidgets.QMessageBox.critical(None, "Erro inesperado", msg[-4000:])
        except Exception:
            print(msg, file=sys.stderr)
    sys.excepthook = handler


def main():
    _apply_high_dpi()
    app = QtWidgets.QApplication(sys.argv)
    _set_app_meta(app)
    _apply_theme(app)
    _install_excepthook()

    # Preferimos o launcher 'run_app' (se existir); senão, criamos a janela direto.
    try:
        from app.shell.main_window import run_app
        return run_app()
    except Exception:
        from app.shell.main_window import MainWindow
        w = MainWindow()
        w.resize(1100, 700)
        # título visível da janela
        try:
            w.setWindowTitle(f"{APP_NAME} — {APP_VERSION}")
        except Exception:
            w.setWindowTitle(APP_NAME)
        w.show()
        return app.exec()


if __name__ == "__main__":
    sys.exit(main())
