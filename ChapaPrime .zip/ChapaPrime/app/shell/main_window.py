# ============================
# FILE: app/shell/main_window.py
# ============================
from __future__ import annotations

import os
from PySide6 import QtWidgets, QtGui, QtCore

# importe as VIEWS (widgets) e os CONTROLLERS
from app.tabs.op.view import OpView
from app.tabs.op.controller import OpController
from app.tabs.planner.view import PlannerView
from app.tabs.planner.controller import PlannerController


class MainWindow(QtWidgets.QMainWindow):
    """
    Janela principal com TabWidget.
    - Inicia maximizada (mais área para o preview).
    - F11: alterna Tela Cheia.
    - Ctrl+H: oculta/mostra o painel superior da view atual (se a view tiver toggle_panel()).
    """
    def __init__(self):
        super().__init__()

        self.setWindowTitle("SteelFlow Planner — Premium Suite")

        # ícone do app (ajuste o caminho se seu ícone estiver em outro lugar)
        icon_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),  # app/shell -> app
            "resources", "icons", "app.png"
        )
        if os.path.exists(icon_path):
            self.setWindowIcon(QtGui.QIcon(icon_path))

        # TabWidget principal
        self.tabs = QtWidgets.QTabWidget()
        self.setCentralWidget(self.tabs)

        # Abas
        self._controllers = []  # mantém referências
        self._attach_tab(PlannerView, PlannerController, "Planner (Corte)")
        self._attach_tab(OpView, OpController, "Dobra (OP)")

        # Status bar
        self.statusBar().showMessage("Pronto.")

        # Menu/atalhos
        self._build_actions()

        # Inicia maximizado (melhor para o preview)
        self.setWindowState(QtCore.Qt.WindowMaximized)

    # ---------- Abas / Controllers ----------
    def _attach_tab(self, view_cls, controller_cls, title: str):
        """
        Cria a view (QWidget), instancia o controller e adiciona a view na aba.
        Mantém referência ao controller para evitar garbage collection.
        """
        view = view_cls()

        # Alguns controllers exigem view no __init__, outros não.
        try:
            controller = controller_cls(view)  # padrão: controller(view)
        except TypeError:
            controller = controller_cls()      # fallback: controller()
            if hasattr(controller, "set_view"):
                controller.set_view(view)

        self._controllers.append(controller)
        self.tabs.addTab(view, title)

    # ---------- Menu / Ações ----------
    def _build_actions(self):
        menubar = self.menuBar()
        view_menu = menubar.addMenu("&Exibir")

        # Tela cheia (F11)
        act_full = QtGui.QAction("Tela &Cheia (F11)", self)
        act_full.setShortcut(QtGui.QKeySequence(QtCore.Qt.Key_F11))
        act_full.triggered.connect(self._toggle_fullscreen)
        view_menu.addAction(act_full)

        # Ocultar/Mostrar painel da view atual (Ctrl+H)
        act_panel = QtGui.QAction("&Ocultar/Mostrar Painel (Ctrl+H)", self)
        act_panel.setShortcut(QtGui.QKeySequence("Ctrl+H"))
        act_panel.triggered.connect(self._toggle_current_panel)
        view_menu.addAction(act_panel)

        # Ajustar preview (se a view atual tiver fit_preview)
        act_fit = QtGui.QAction("&Ajustar Preview (Ctrl+J)", self)
        act_fit.setShortcut(QtGui.QKeySequence("Ctrl+J"))
        act_fit.triggered.connect(self._fit_current_preview)
        view_menu.addAction(act_fit)

    # ---------- Slots ----------
    def _toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
            # volta maximizado para manter experiência
            self.setWindowState(QtCore.Qt.WindowMaximized)
        else:
            self.showFullScreen()

    def _current_view(self):
        # Retorna o widget da aba atual
        idx = self.tabs.currentIndex()
        if idx < 0:
            return None
        return self.tabs.widget(idx)

    def _toggle_current_panel(self):
        view = self._current_view()
        # Só executa se a view expõe toggle_panel()
        if view and hasattr(view, "toggle_panel") and callable(view.toggle_panel):
            view.toggle_panel()
        else:
            QtWidgets.QMessageBox.information(
                self, "Painel",
                "A view atual não possui painel ocultável."
            )

    def _fit_current_preview(self):
        view = self._current_view()
        # Só executa se a view expõe fit_preview()
        if view and hasattr(view, "fit_preview") and callable(view.fit_preview):
            try:
                view.fit_preview()
            except Exception:
                pass

# Função de entrada padrão chamada por app.main
def run_app():
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    win = MainWindow()
    win.show()
    app.exec()
