# -*- coding: utf-8 -*-
# Centraliza metadados do aplicativo
APP_NAME = "ChapaPrime"
APP_VERSION = "1.0.0"
