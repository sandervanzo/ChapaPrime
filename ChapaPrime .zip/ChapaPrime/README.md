
# SteelFlow Premium Suite

App modular (PySide6) com abas **Planner (Corte)** e **Dobra (OP)**, tema escuro e exportação de PDF.
Estrutura separada por módulos para facilitar manutenção.

## Rodar
```bash
pip install -r requirements.txt
python -m app.main
```

## Pastas
- `app/` – UI e shells
- `services/` – cálculos, PDF, storage
- `export/op_dobra_pdf.py` – wrapper de compatibilidade
- `resources/icons/app.png` – ícone (substitua pelo seu logo)
