
@echo off
setlocal
python --version
python -m pip install -r requirements.txt
python -m app.main
pause
