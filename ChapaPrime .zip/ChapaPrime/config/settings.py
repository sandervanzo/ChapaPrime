# -*- coding: utf-8 -*-
"""
Carrega configurações do app a partir de config/app_settings.json.
Se o JSON não existir ou der erro, usa valores padrão (fallback).
Uso em outros arquivos:
    from config.settings import settings
    densidade = settings["default_density_kg_m3"]
    kerf = settings["kerf_mm"]
"""
from __future__ import annotations
import json
from pathlib import Path

_DEFAULTS = {
    "units": {"length": "mm", "thickness": "mm"},
    "kerf_mm": 3.0,
    "default_density_kg_m3": 8000,
}

def _load() -> dict:
    # este arquivo fica em: .../config/settings.py
    here = Path(__file__).resolve()
    cfg_path = here.parent / "app_settings.json"
    if cfg_path.exists():
        try:
            data = json.loads(cfg_path.read_text(encoding="utf-8"))
            merged = dict(_DEFAULTS)
            merged.update(data)
            return merged
        except Exception:
            return dict(_DEFAULTS)
    return dict(_DEFAULTS)

settings = _load()
